import {Composition,Folder,Still} from 'remotion';
import {FullV6, LaunchV6, MotionLab, MotionPrototype, MotionShot, full as fullV6, launch as launchV6, lab, prototype as prototypeV6, duration as v6Duration} from './v6/motion/Film';
import {BaseScene,FullBase,LaunchBase} from './v6/Base';
import {duration as baseDuration,full as fullBase,launch as launchBase} from './v6/storyboard';
import {FullV5,LaunchV5,NarratedV5,PrototypeV5,ThumbnailV5} from './v5/Films';
import {duration,FPS,full,launch,prototype} from './v5/timeline';

const video={width:1920,height:1080,fps:FPS};
export const Root=()=> <>
  <Composition id="AlmoxERP-Full-V5" component={FullV5} durationInFrames={duration(full)} {...video}/>
  <Composition id="AlmoxERP-Launch-V5" component={LaunchV5} durationInFrames={duration(launch)} {...video}/>
  <Composition id="AlmoxERP-Full-V5-Narrated" component={NarratedV5} durationInFrames={duration(full)} {...video}/>
  <Composition id="AlmoxERP-MotionPrototype-V5" component={PrototypeV5} durationInFrames={duration(prototype)} {...video}/>
  <Folder name="V6-Filmes">
    <Composition id="AlmoxERP-Full-V6" component={FullV6} durationInFrames={v6Duration(fullV6)} {...video}/>
    <Composition id="AlmoxERP-Launch-V6" component={LaunchV6} durationInFrames={v6Duration(launchV6)} {...video}/>
    <Composition id="AlmoxERP-MotionPrototype" component={MotionPrototype} durationInFrames={v6Duration(prototypeV6)} {...video}/>
    <Composition id="AlmoxERP-MotionLab" component={MotionLab} durationInFrames={v6Duration(lab)} {...video}/>
    <Folder name="Tomadas-V6">
      {fullV6.map(scene=><Composition key={scene.id} id={`V6-Motion-${scene.id}`} component={MotionShot} defaultProps={{id:scene.id}} durationInFrames={scene.frames} {...video}/>)}
    </Folder>
  </Folder>
  <Folder name="V6-Etapa-1">
    <Composition id="AlmoxERP-Full-V6-Base" component={FullBase} durationInFrames={baseDuration(fullBase)} {...video}/>
    <Composition id="AlmoxERP-Launch-V6-Base" component={LaunchBase} durationInFrames={baseDuration(launchBase)} {...video}/>
    {fullBase.map(scene=><Composition key={scene.id} id={`V6-Base-${scene.id}`} component={BaseScene} defaultProps={{scene}} durationInFrames={scene.frames} {...video}/>)}
  </Folder>
  <Still id="AlmoxERP-Thumbnail-V5" component={ThumbnailV5} width={video.width} height={video.height}/>
</>;
