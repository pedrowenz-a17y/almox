import {Img,staticFile} from 'remotion';
import type {CSSProperties} from 'react';
import {centerOf,fitCapture,focusCrop,mapCapturePoint,type Rect,type Viewport} from './geometry';
import registry from '../../public/etapa1/manifest.json';

export type Capture={
  filename:string; viewport:Viewport; dpr:number; bounds:Rect; visible:Rect;
  regions:Record<string,{bounds:Rect;visible:Rect|null}>; png:Viewport;
};
export const assets=registry.assets as Record<string,Capture>;
export const rectStyle=({x,y,width,height}:Rect):CSSProperties=>({position:'absolute',left:x,top:y,width,height});
export function screenshotCrop(asset:Capture,mode:'focus'|'screen'){
  return mode==='focus'?focusCrop(asset.viewport,asset.visible):{x:0,y:0,...asset.viewport};
}
export function ScreenCapture({assetId,slot,mode='screen',cursor}:{
  assetId:string;slot:Rect;mode?:'focus'|'screen';cursor?:string;
}) {
  const asset=assets[assetId];
  if(!asset)return <div style={{...rectStyle(slot),color:'#765867',background:'#eee3e9',display:'grid',placeItems:'center',fontSize:24}}>Captura pendente · {assetId}</div>;
  const crop=screenshotCrop(asset,mode);
  const fitted=fitCapture(crop,slot);
  const region=cursor?asset.regions[cursor]?.visible:null;
  const point=region?mapCapturePoint(centerOf(region),crop,slot):null;
  return <>
    <div style={{...rectStyle(fitted),background:'#1d1920',overflow:'hidden',boxShadow:'0 14px 40px #291e2a38',outline:'1px solid #291e2a28',borderRadius:mode==='focus'?12:10}}>
      <Img src={staticFile('etapa1/'+asset.filename)} style={{position:'absolute',left:-crop.x*fitted.scale,top:-crop.y*fitted.scale,width:asset.viewport.width*fitted.scale,height:asset.viewport.height*fitted.scale,maxWidth:'none'}}/>
    </div>
    {point&&<svg style={{position:'absolute',left:point.x,top:point.y}} width={36} height={45} viewBox="0 0 30 34" aria-hidden="true"><path d="M3 2L26 20L16 21L12 31L3 2Z" fill="#fdfaf9" stroke="#211921" strokeWidth="2.2" strokeLinejoin="round"/></svg>}
  </>;
}
