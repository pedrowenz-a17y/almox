import type {CSSProperties, ReactNode} from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile} from 'remotion';
import {assets, rectStyle} from '../Assets';
import {centerOf, fitCapture, type Rect} from '../geometry';

export type Tone = 'paper' | 'graphite' | 'red';
export const accent = '#dc1646';
const ink = {paper:'#181718',graphite:'#faf8f7',red:'#fff8f5'};
const secondary = {paper:'#5d5656',graphite:'#c3b8bb',red:'#fff0e9'};
const easing = Easing.bezier(.22, .72, .21, 1);
export const progress = (frame:number,start:number,end:number) => interpolate(frame,[start,end],[0,1],{
  easing,extrapolateLeft:'clamp',extrapolateRight:'clamp',
});
export const linear = (frame:number,start:number,end:number) => interpolate(frame,[start,end],[0,1],{
  extrapolateLeft:'clamp',extrapolateRight:'clamp',
});
export const liftSpring = (frame:number,fps:number) => spring({frame:Math.max(0,frame), fps,config:{damping:24,mass:.82,stiffness:168},durationInFrames:24});
export const mix = (a:number,b:number,t:number) => a+(b-a)*t;
export const mixRect = (a:Rect,b:Rect,t:number):Rect => box(mix(a.x,b.x,t),mix(a.y,b.y,t),mix(a.width,b.width,t),mix(a.height,b.height,t));
export const box = (x:number,y:number,width:number,height:number):Rect => ({x,y,width,height});
export const whole = (id:string) => box(0,0,assets[id].viewport.width,assets[id].viewport.height);
export function region(id:string,name?:string) {
  const asset=assets[id];
  if(!name)return asset.visible;
  const rect=asset.regions[name]?.visible;
  if(!rect || rect.width<=0 || rect.height<=0)throw Error(`Região ausente ou fora da captura: ${id}/${name}`);
  return rect;
}
export function around(id:string,r:Rect,xPad:number,yPad:number):Rect {
  const v=assets[id].viewport;
  const x=Math.max(0,r.x-xPad), y=Math.max(0,r.y-yPad);
  return box(x,y,Math.min(v.width,r.x+r.width+xPad)-x,Math.min(v.height,r.y+r.height+yPad)-y);
}
export const projectRect = (source:Rect,crop:Rect,target:Rect):Rect => {
  const fitted=fitCapture(crop,target);
  return box(fitted.x+(source.x-crop.x)*fitted.scale,fitted.y+(source.y-crop.y)*fitted.scale,source.width*fitted.scale,source.height*fitted.scale);
};
export const withoutJump = (frame:number,first:number,peak:number,last:number,settled=peak) =>
  progress(frame,first,peak)*(1-progress(frame,settled,last));

export function Stage({tone,frame,children}:{tone:Tone;frame:number;children:ReactNode}) {
  const goes=linear(frame,0,240);
  const background={
    paper:'radial-gradient(ellipse at 78% 57%,#fff 5%,#ebe7e1 78%)',
    graphite:'radial-gradient(ellipse at 75% 63%,#302127 0%,#171619 48%,#101012 100%)',
    red:'radial-gradient(ellipse at 72% 80%,#b91e3e 0%,#a00e30 48%,#780a28 100%)',
  };
  return <AbsoluteFill style={{background:background[tone],color:ink[tone],fontFamily:'DM Sans, Arial',overflow:'hidden'}}>
    <div style={{position:'absolute',inset:-94,opacity:tone==='paper'?.32:.30,transform:`translateX(${mix(0,-14,goes)}px)`,backgroundImage:`linear-gradient(${tone==='paper'?'#29212819':'#fff1'} 1px,transparent 1px),linear-gradient(90deg,${tone==='paper'?'#29212819':'#fff1'} 1px,transparent 1px)`,backgroundSize:'84px 84px',maskImage:'radial-gradient(ellipse at 75% 55%,#000,transparent 69%)'}}/>
    <div style={{position:'absolute',inset:0,background:tone==='graphite'?'radial-gradient(ellipse at 100% 23%, #d613332c,transparent 54%)':'none'}}/>
    {children}
  </AbsoluteFill>;
}
export function Label({text,tone='paper',x=86,y=38}:{text:string;tone?:Tone;x?:number;y?:number}) {
  return <div style={{position:'absolute',left:x,top:y,display:'flex',alignItems:'center',gap:14,fontSize:22,fontWeight:700,color:secondary[tone]}}>
    <i style={{display:'block',width:24,height:3,background:tone==='red'?'#fff':accent}}/>{text}
  </div>;
}
export function Title({text,frame,size=87,x=84,y=82,width=1750,lines,delay=-11}:{
  text:string;frame:number;size?:number;x?:number;y?:number;width?:number;lines?:string[];delay?:number;
}) {
  return <div style={{position:'absolute',left:x,top:y,width,zIndex:20,margin:0,fontFamily:'Manrope,Arial',fontWeight:800,fontSize:size,lineHeight:1.06,letterSpacing:-size*.065}}>
    {(lines??[text]).map((line,i)=><div key={line} style={{overflow:'hidden',paddingBottom:6}}>
      <div style={{transform:`translateY(${(1-progress(frame,delay+i*5,delay+i*5+17))*110}%)`}}>{line}</div>
    </div>)}
  </div>;
}
export function Caption({text,frame,start=0,tone='paper',x=86,y=968,width=1720}:{
  text:string;frame:number;start?:number;tone?:Tone;x?:number;y?:number;width?:number;
}) {
  const p=progress(frame,start,start+9);
  return <div style={{position:'absolute',left:x,top:y,width,fontSize:31,fontWeight:600,lineHeight:1.25,opacity:p,transform:`translateY(${mix(14,0,p)}px)`,color:secondary[tone],zIndex:21}}>{text}</div>;
}
function exclusionClip(width:number,height:number,holes:Rect[]) {
  const subpath=({x,y,width,height}:Rect)=>`M ${x} ${y} h ${width} v ${height} h ${-width} Z`;
  return `path(evenodd, "${[box(0,0,width,height),...holes].map(subpath).join(' ')}")`;
}
type CursorCue={to:Rect;from?:Rect;frame:number;arrive:number;click?:number;leave?:number};

export function CaptureWindow({id,crop=whole(id),slot,radius=19,angle=0,yaw=0,tilt=0,opacity=1,reveal=1,bezel=false,shadow=true,holes=[],cursor,z=3,blur=0,children}:{
  id:string;crop?:Rect;slot:Rect;radius?:number;angle?:number;yaw?:number;tilt?:number;opacity?:number;reveal?:number;
  bezel?:boolean;shadow?:boolean;holes?:Rect[];cursor?:CursorCue;z?:number;blur?:number;children?:ReactNode;
}) {
  const asset=assets[id];
  if(!asset)throw Error(`Captura não registrada: ${id}`);
  const fitted=fitCapture(crop,slot);
  const scale=fitted.scale;
  const inside=(r:Rect)=>box((r.x-crop.x)*scale,(r.y-crop.y)*scale,r.width*scale,r.height*scale);
  const motion:CSSProperties={...rectStyle(fitted),opacity,zIndex:z,transform:`perspective(1850px) rotateX(${tilt}deg) rotateY(${yaw}deg) rotateZ(${angle}deg)`,filter:blur>0?`blur(${blur}px)`:undefined};
  return <div style={motion}>
    {bezel&&<div style={{position:'absolute',inset:-12,borderRadius:radius+12,background:'linear-gradient(135deg,#626269,#151619 30%,#0f0e12 70%,#555157)',border:'1px solid #9996',boxShadow:'0 26px 64px #05050866'}}/>}
    <div style={{position:'absolute',inset:0,borderRadius:radius,overflow:'hidden',outline:bezel?'':'1px solid #a5a4a42b',
      background:'#24262c',boxShadow:shadow?'0 18px 44px #09070c39, 0 3px 8px #09070c35':undefined,
      clipPath:reveal<1?`inset(0 ${(1-reveal)*100}% 0 0 round ${radius}px)`:undefined}}>
      <div style={{position:'absolute',inset:0,overflow:'hidden',borderRadius:radius,clipPath:holes.length?exclusionClip(fitted.width,fitted.height,holes.map(inside)):undefined}}>
        <Img src={staticFile('etapa1/'+asset.filename)} style={{position:'absolute',width:asset.viewport.width*scale,height:asset.viewport.height*scale,left:-crop.x*scale,top:-crop.y*scale,maxWidth:'none'}}/>
      </div>
      {children}
    </div>
    {cursor&&<Cursor cue={cursor} crop={crop} scale={scale} reveal={reveal}/>}
  </div>;
}
function Cursor({cue,crop,scale,reveal}:{cue:CursorCue;crop:Rect;scale:number;reveal:number}) {
  const end=centerOf(cue.to);
  const origin=cue.from?centerOf(cue.from):{x:end.x+Math.min(86,crop.width*.24),y:end.y+Math.min(58,crop.height*.2)};
  const p=progress(cue.frame,cue.arrive-15,cue.arrive);
  const click=cue.click??Infinity;
  const pulse=Number.isFinite(click)?linear(cue.frame,click,click+12):1;
  const press=Number.isFinite(click)?withoutJump(cue.frame,click-2,click,click+5):0;
  const opacity=progress(cue.frame,cue.arrive-18,cue.arrive-12)*(1-(cue.leave===undefined?0:progress(cue.frame,cue.leave,cue.leave+6)));
  const x=(mix(origin.x,end.x,p)-crop.x)*scale, y=(mix(origin.y,end.y,p)-crop.y)*scale;
  if(x<0||x>=crop.width*scale*reveal||y<0||y>=crop.height*scale)return null;
  return <div style={{position:'absolute',left:x,top:y,opacity,zIndex:19,pointerEvents:'none'}}>
    {pulse<1&&cue.frame>=click&&<div style={{position:'absolute',height:48,width:48,top:-24,left:-24,transform:`scale(${mix(.22,1.3,pulse)})`,border:'3px solid #f64668',borderRadius:'50%',opacity:1-pulse}}/>}
    <svg width="35" height="44" viewBox="0 0 35 44" style={{position:'absolute',left:-2,top:-2,filter:'drop-shadow(0 1px 2px #0008)',transform:`scale(${1-press*.17})`,transformOrigin:'2px 2px'}}>
      <path d="M2 2L29 23L18 24L13 36L2 2Z" fill="#fff" stroke="#1f1d24" strokeWidth="2.3" strokeLinejoin="round"/>
    </svg>
  </div>;
}
export function CutPiece({id,area,slot,amount,priority=5,angle=0,radius=12}:{
  id:string;area:Rect;slot:Rect;amount:number;priority?:number;angle?:number;radius?:number;
}) {
  return amount>0?<CaptureWindow id={id} crop={area} slot={slot} radius={radius*amount} angle={angle*amount} shadow={amount>.15} z={priority}/>:null;
}
export function Connector({frame,start,end,path,dark=false,terminal=false}:{
  frame:number;start:number;end:number;path:string;dark?:boolean;terminal?:boolean;
}) {
  const t=progress(frame,start,end);
  return <svg viewBox="0 0 1920 1080" width="1920" height="1080" style={{position:'absolute',left:0,top:0,zIndex:2,pointerEvents:'none',overflow:'visible'}} fill="none">
    <path d={path} stroke={dark?'#ff93a643':'#812a3e29'} strokeWidth="2" strokeDasharray="4 9"/>
    <path d={path} stroke={dark?'#ff6c89':'#bd1744'} strokeWidth="3" strokeLinecap="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1-t} opacity={terminal?1:.85}/>
  </svg>;
}
export function Success({frame,start,x,y}:{frame:number;start:number;x:number;y:number}) {
  const t=progress(frame,start,start+14);
  if(t<=0)return null;
  return <svg viewBox="0 0 64 64" width="64" height="64" style={{position:'absolute',left:x,top:y,zIndex:16,transform:`scale(${mix(.65,1,t)})`,opacity:t}}>
    <circle cx="32" cy="32" r="29" fill="#d9f4e6" stroke="#8fd0b0" strokeWidth="2"/>
    <path d="M18 32l10 10 19-20" pathLength="1" fill="none" stroke="#08794c" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1-t}/>
  </svg>;
}
export function OfficialLogo({slot,opacity=1}: {slot:Rect;opacity?:number}) {
  return <Img src={staticFile('etapa1/uca-oficial.png')} style={{...rectStyle(slot),objectFit:'contain',opacity}}/>;
}
