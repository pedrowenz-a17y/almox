import {useVideoConfig} from 'remotion';
import {accent,around,box,Caption,CaptureWindow,Connector,CutPiece,Label,liftSpring,linear,mix,mixRect,progress,projectRect,region,Stage,Success,Title,whole,withoutJump} from './Stage';
import type {ShotProps} from './Heroes';

export function Assistant({frame:f,compact}:ShotProps) {
  const typeAt=compact?39:52;
  const sent=compact?122:139;
  const draft='assistente-digitado';
  const answer='assistente-resposta';
  const id=f<typeAt?'assistente-local':f<=sent?draft:answer;
  const oldCrop=around(draft,region(draft),12,16);
  const slot=box(124,231,920,685);
  const form=region(draft,'text');
  const formPoint=box(form.x+18,form.y+9,52,25);
  const message=region(answer,'reply');
  const responseCrop=around(answer,region(answer),12,14);
  const origin=projectRect(message,responseCrop,slot);
  const fly=withoutJump(f,sent+12,sent+47,280,258);
  const key=progress(f,typeAt,typeAt+46);
  const typingMask=f>=typeAt&&f<typeAt+46?box(form.x+15+key*216,form.y+8,216*(1-key),27):null;
  return <Stage tone="paper" frame={f}>
    <Label text="Assistente do Almox"/>
    <Title text="Uma pergunta. Uma orientação." frame={f} size={79}/>
    <CaptureWindow id={id} crop={id===answer?responseCrop:oldCrop} slot={mixRect({...slot,y:slot.y+44},slot,progress(f,0,24))}
      radius={21} yaw={mix(-7,0,progress(f,0,20))}
      holes={id===answer&&fly>0?[message]:typingMask?[typingMask]:[]}
      cursor={id===draft?{from:formPoint,to:region(draft,'button'),frame:f,arrive:sent-5,click:sent,leave:sent}:undefined}/>
    {id===answer&&<CutPiece id={answer} area={message} slot={mixRect(origin,box(1038,410,803,414),fly)} amount={fly} angle={2}/>}
    <div style={{position:'absolute',left:1074,top:280,maxWidth:630,fontSize:44,fontWeight:750,lineHeight:1.13,letterSpacing:-1.5,opacity:progress(f,23,48),color:'#272024'}}>
      {f<=sent?'“Como usar o QR Code?”':'Orientação sobre etiquetas'}
    </div>
    {f<=sent&&<Connector frame={f} start={27} end={60} path="M 1031 378 H 1115 V 420 H 1238"/>}
    <Caption text={f<=sent?'A pergunta é enviada no modo local.':'Resposta do assistente local com a consulta da unidade desativada.'} frame={f} start={f<=sent?14:sent}/>
  </Stage>;
}

export function Replenishment({frame:f}:ShotProps) {
  const id='reposicao';
  const row=region(id,'linha');
  const crop=around(id,row,19,103);
  const slot=box(163,314,1594,479);
  const fit=projectRect(row,crop,slot);
  const lift=withoutJump(f,35,68,149,126);
  return <Stage tone="paper" frame={f}>
    <Label text="Reposição"/>
    <Title text="Organize o abastecimento." frame={f}/>
    <CaptureWindow id={id} crop={crop} slot={slot} opacity={progress(f,0,16)} reveal={progress(f,0,27)} holes={lift>0?[row]:[]}/>
    <CutPiece id={id} area={row} slot={mixRect(fit,box(210,715,1500,111),lift)} amount={lift}/>
    <Caption text="Disponível, mínimo, em compra e meta aparecem na linha do material." frame={f} start={27}/>
  </Stage>;
}

export function Inventory({frame:f,compact}:ShotProps) {
  const {fps}=useVideoConfig();
  const reviewAt=compact?52:67, resultAt=compact?118:131;
  const id=f<reviewAt?'inventario-autor':f<resultAt?'inventario-revisor':'inventario-aprovado';
  const area=region(id);
  const p=progress(f,0,25);
  const slot=box(678,207,1092,714);
  const rows=around(id,area,id==='inventario-aprovado'?11:20,id==='inventario-aprovado'?43:18);
  const values=[{label:'Sistema',value:'24'},{label:'Contagem',value:'23'},{label:'Diferença',value:'−1'}];
  return <Stage tone="graphite" frame={f}>
    <Label text="Inventário" tone="graphite"/>
    <Title text="Revise a contagem." frame={f}/>
    <CaptureWindow id={id} crop={rows} slot={mixRect({...slot,x:slot.x+74,y:slot.y+28},slot,p)} radius={22} yaw={mix(-7,0,p)}
      reveal={progress(f,1,18)} opacity={p}/>
    <div style={{position:'absolute',left:136,top:272,display:'grid',gap:11}}>
      {values.map((cell,i)=>{
        const show=liftSpring(f-15-i*6,fps);
        return <div key={cell.label} style={{display:'flex',alignItems:'center',justifyContent:'space-between',width:470,height:124,padding:'0 27px',borderRadius:13,
          border:'1px solid #ffffff34',background:i===2?'#611831':'#252329',color:'#fff',opacity:show,transform:`translateY(${(1-show)*56}px)`}}>
          <div style={{fontSize:29,fontWeight:650}}>{cell.label}</div>
          <strong style={{fontFamily:'Manrope',fontSize:64,letterSpacing:-4,overflow:'hidden'}}><span style={{display:'block',transform:`translateY(${(1-show)*105}%)`}}>{cell.value}</span></strong>
        </div>;
      })}
    </div>
    {id==='inventario-aprovado'&&<Success frame={f} start={resultAt+4} x={1695} y={733}/>}
    <Caption tone="graphite" text={f<reviewAt?'O autor fica impedido de aprovar a própria contagem.':f<resultAt?'Outra conta autorizada revisa a mesma contagem.':'A linha muda para Aprovado após a ação do revisor.'} frame={f} start={f<reviewAt?10:f<resultAt?reviewAt:resultAt}/>
  </Stage>;
}

export function Shift({frame:f}:ShotProps) {
  const accept=112;
  const id=f<63?'turno-aguardando':f<=accept?'turno-aceitar':'turno-assumido';
  const focus=region(id);
  const crop=around(id,focus,20,id==='turno-aceitar'?20:41);
  const dialogue=id==='turno-aceitar';
  const move=progress(f,63,82);
  const center=box(107,317,1699,415);
  const modal=box(566,256,788,646);
  const arrival=projectRect(focus,crop,dialogue?modal:center);
  return <Stage tone="paper" frame={f}>
    <Label text="Passagem de turno"/>
    <Title text="A responsabilidade tem aceite." frame={f} size={81}/>
    <CaptureWindow id={id} crop={crop} slot={dialogue?mixRect(box(465,328,990,537),modal,move):center}
      radius={dialogue?18:12} reveal={progress(f,0,17)}
      cursor={dialogue?{to:region(id,'button'),frame:f,arrive:accept-8,click:accept}:undefined}/>
    {f<63&&<Connector frame={f} start={17} end={49} path="M 235 765 H 949 Q 997 765 997 718 V 626"/>}
    {f>accept&&<Success frame={f} start={accept+5} x={arrival.x+arrival.width-76} y={Math.min(845,arrival.y+arrival.height+36)}/>}
    <Caption text={f<63?'A responsabilidade atual permanece enquanto o aceite está pendente.':dialogue?'A pessoa indicada aceita com a própria conta.':'O titular muda após “Aceitar e assumir turno”.'}
      frame={f} start={f<63?13:dialogue?63:accept+1}/>
  </Stage>;
}

function CsvDocument({f,opacity}:{f:number;opacity:number}) {
  const p=progress(f,0,29);
  return <div style={{position:'absolute',left:143,top:330,width:251,height:327,zIndex:4,opacity:p*opacity,
    transform:`perspective(1050px) rotateY(${mix(-38,-10,p)}deg) rotateZ(${mix(-9,-4,p)}deg) translateY(${(1-p)*90}px)`}}>
    <svg viewBox="0 0 251 327" width="251" height="327" aria-hidden="true" style={{filter:'drop-shadow(0 20px 25px #1d152a38)'}}>
     <path d="M18 0h146l87 89v220q0 18-18 18H18q-18 0-18-18V18Q0 0 18 0Z" fill="#f6efec" stroke="#fdf8f5" strokeWidth="2"/>
     <path d="M164 0v70q0 19 19 19h68" fill="#e7dada" stroke="#d4c4c3" strokeWidth="2"/>
     <path d="M37 145h177m-177 26h177m-177 26h177m-138-52v52m50-52v52" fill="none" stroke="#9f6675" strokeWidth="2"/>
    </svg>
    <b style={{position:'absolute',left:41,top:229,color:'#961b3a',fontSize:54,letterSpacing:-3}}>CSV</b>
  </div>;
}
export function Reconciliation({frame:f}:ShotProps) {
  const previewAt=68, reviewAt=138;
  const id=f<previewAt?'csv-importar':f<reviewAt?'csv-previa':'csv-revisao';
  const r=region(id);
  const cutoff=id==='csv-importar'?box(r.x,r.y,r.width,484):r;
  const crop=around(id,cutoff,12,10);
  const slot=id==='csv-revisao'?box(480,209,960,733):id==='csv-previa'?box(203,327,1514,492):box(507,234,1245,649);
  const panel=projectRect(cutoff,crop,slot);
  const rowH=r.height/4;
  const divider=id==='csv-previa'&&f<previewAt+23?Array.from({length:3},(_,i)=>{
    const p=progress(f,previewAt+i*5,previewAt+i*5+12);
    return box(r.x+r.width*p,r.y+rowH*(i+1),r.width*(1-p),rowH);
  }).filter(clip=>clip.width>0):[];
  return <Stage tone="graphite" frame={f}>
    <Label text="Conciliação com ERP" tone="graphite"/>
    <Title text="Confira as diferenças." frame={f}/>
    {f<previewAt&&<CsvDocument f={f} opacity={1-progress(f,previewAt-18,previewAt)}/>}
    {f<previewAt&&<Connector frame={f} start={23} end={54} path="M 392 513 C 447 513 458 555 525 555 H 640" dark/>}
    <CaptureWindow id={id} crop={crop} slot={slot} reveal={id==='csv-previa'?1:progress(f,id==='csv-revisao'?reviewAt-4:4,id==='csv-revisao'?reviewAt+11:22)}
      opacity={id==='csv-previa'?progress(f,previewAt-2,previewAt+4):1} holes={divider}
      cursor={id==='csv-revisao'?{to:region(id,'button'),frame:f,arrive:181,leave:195}:undefined}/>
    {id==='csv-previa'&&<div style={{position:'absolute',top:panel.y+panel.height+22,left:panel.x,height:3,width:panel.width*progress(f,previewAt+3,previewAt+32),background:'#e65072'}}/>}
    <Caption tone="graphite" text={f<previewAt?'Associe as colunas ao importar e confira os critérios.':f<reviewAt?'A prévia distingue linhas que conferem e linhas com diferenças.':'Outra pessoa autorizada analisa as diferenças e registra o parecer.'}
      frame={f} start={f<previewAt?12:f<reviewAt?previewAt:reviewAt}/>
  </Stage>;
}

export function Alerts({frame:f,compact}:ShotProps) {
  const pending='alertas-pendentes', read='alerta-lido';
  const action=compact?94:108;
  const card=region(pending,'first'), second=region(pending,'second');
  const crop=around(pending,box(card.x,card.y,card.width,second.y+second.height-card.y),11,12);
  const slot=box(116,224,1688,711);
  const origin=projectRect(second,crop,slot);
  const lift=withoutJump(f,9,25,action-17,action-37);
  const swap=f>action;
  const id=swap?read:pending;
  const visibleCrop=swap?around(read,region(read),14,17):crop;
  const visibleSlot=swap?box(155,315,1610,475):slot;
  return <Stage tone="paper" frame={f}>
    <Label text="Central de alertas"/>
    <Title text="Acompanhe as pendências." frame={f} size={82}/>
    <CaptureWindow id={id} crop={visibleCrop} slot={visibleSlot} radius={17} reveal={progress(f,0,17)} holes={!swap&&lift>0?[second]:[]}
      cursor={!swap?{to:region(pending,'read'),frame:f,arrive:action-8,click:action}:undefined}/>
    {!swap&&<CutPiece id={pending} area={second} slot={mixRect(origin,box(origin.x+67,origin.y+42,origin.width,origin.height),lift)} amount={lift} angle={1.3}/>}
    <Caption text={swap?'A leitura fica registrada e a pendência permanece.':'Veja o aviso, abra o registro de origem ou marque como lido.'} frame={f} start={swap?action+1:10}/>
  </Stage>;
}

export function Management({frame:f,compact}:ShotProps) {
  const {fps}=useVideoConfig();
  const id='gerencial';
  const body=region(id);
  const crop=around(id,body,9,28);
  const cut=compact?103:128;
  const inContext=f>=cut;
  const further=progress(f,cut,cut+30);
  const slot=box(139,259,1643,567);
  const x=body.x,y=body.y,w=body.width,h=body.height;
  const slices=[box(x,y,w*.36,h),box(x+w*.36,y,w*.32,h),box(x+w*.68,y,w*.32,h)];
  const phases=slices.map((area,i)=>{
    const show=liftSpring(f-3-i*5,fps);
    const hold=(1-progress(f,26+i*4,49+i*4));
    const lift=hold*(.35+show*.65);
    const origin=projectRect(area,crop,slot);
    return {area,lift,show,pos:mixRect(origin,{...origin,x:origin.x+(i-1)*50,y:origin.y-(2-i)*31},lift)};
  });
  const mobile='gerencial-mobile';
  return <Stage tone="paper" frame={f}>
    <Label text="Visão da operação"/>
    <Title text="Compare as unidades." frame={f}/>
    {!inContext?<CaptureWindow id={id} crop={crop} slot={slot} holes={phases.filter(p=>p.lift>0).map(p=>p.area)} opacity={progress(f,1,17)}/>
      :<CaptureWindow id={id} crop={box(0,245,1440,755)} slot={mixRect(slot,box(132,259,1160,630),further)}
        yaw={mix(0,-9,further)} tilt={mix(0,4,further)} radius={18} bezel={further>.5}/>}
    {!inContext&&phases.map((p,i)=><div key={i} style={{position:'absolute',inset:0,zIndex:5+i,opacity:p.show}}><CutPiece id={id} area={p.area} slot={p.pos} amount={p.lift}/></div>)}
    {inContext&&<CaptureWindow id={mobile} crop={whole(mobile)} slot={mixRect(box(1540,245,301,690),box(1404,228,347,699),further)}
      yaw={mix(14,0,further)} opacity={further} bezel radius={27}/>}
    <Caption text={inContext?'A visão acompanha a operação nas unidades autorizadas.':'Compare filas e a espera mais antiga conhecida.'} frame={f} start={inContext?cut:10}/>
  </Stage>;
}

const phrases=['Do material.','À entrega.','Ao recebimento.'];
export function LaunchType({frame:f}:ShotProps) {
  const off=progress(f,44,57);
  return <Stage tone="red" frame={f}>
    <div style={{position:'absolute',top:90,left:104,width:1409,height:824,opacity:1-off,transform:`translateY(${-94*off}px)`}}>
      {phrases.map((phrase,i)=><Title key={phrase} text={phrase} frame={f} x={0} y={105+i*177} size={133} delay={i*9-10}/>)}
    </div>
    {f>=48&&<Title text="Ao controle da operação." frame={f} x={100} y={411} size={122} width={1700} delay={53}/>}
    <div style={{position:'absolute',left:108,bottom:105,width:mix(90,480,linear(f,0,89)),height:4,background:'#fff6ed'}}/>
  </Stage>;
}
