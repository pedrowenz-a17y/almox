import {Audio} from '@remotion/media';
import {AbsoluteFill, Sequence, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {ComponentType} from 'react';
import {Opening,Search,QRScene,Delivery,Closing,type ShotProps} from './Heroes';
import {Alerts,Assistant,Inventory,LaunchType,Management,Reconciliation,Replenishment,Shift} from './Operations';
import {full as baseFull,launch as baseLaunch} from '../storyboard';
import {linear} from './Stage';
import '../../film.css';

export const shots:Record<string,ComponentType<ShotProps>>={
  Abertura:Opening, Consulta:Search, QR:QRScene, Assistente:Assistant,
  Reposicao:Replenishment, Inventario:Inventory, Entrega:Delivery, Turno:Shift,
  CSV:Reconciliation, Alertas:Alerts, Gerencial:Management, Assinatura:LaunchType, Encerramento:Closing,
};
export type Timing={id:string;frames:number};
export const full=baseFull.map(({id,frames})=>({id,frames}));
export const launch=baseLaunch.map(({id,frames})=>({id,frames}));
export const prototype:Timing[]=[{id:'Consulta',frames:132},{id:'QR',frames:144},{id:'Entrega',frames:144}];
export const lab:Timing[]=[
  {id:'Abertura',frames:120},{id:'Consulta',frames:120},{id:'QR',frames:150},
  {id:'Inventario',frames:114},{id:'Entrega',frames:144},{id:'Gerencial',frames:120},
  {id:'Assinatura',frames:90},{id:'Encerramento',frames:105},
];
export const duration=(scenes:Timing[])=>scenes.reduce((total,s)=>total+s.frames,0);
export const referenceLength=(id:string)=>id==='Assinatura'?90:full.find(s=>s.id===id)?.frames??0;

const Shot=({id,frames,compact}:Timing&{compact:boolean})=>{
  const local=useCurrentFrame();
  const Component=shots[id];
  const nominal=referenceLength(id);
  const frame=linear(local,0,frames-1)*(nominal-1);
  return <Component frame={frame} compact={compact}/>;
};
const Track=({scenes,compact=false,audio}:{scenes:Timing[];compact?:boolean;audio?:string})=>{
  const {fps}=useVideoConfig();
  let start=0;
  return <AbsoluteFill style={{overflow:'hidden'}}>
    {audio&&<Audio src={staticFile(audio)} premountFor={fps}/>}
    {scenes.map((scene)=>{
      const from=start;
      start+=scene.frames;
      return <Sequence key={scene.id} name={scene.id} from={from} durationInFrames={scene.frames} premountFor={fps}>
        <Shot {...scene} compact={compact}/>
      </Sequence>;
    })}
  </AbsoluteFill>;
};
export const FullV6=()=> <Track scenes={full} audio="audio/v6-full.m4a"/>;
export const LaunchV6=()=> <Track scenes={launch} compact audio="audio/v6-launch.m4a"/>;
export const MotionPrototype=()=> <Track scenes={prototype}/>;
export const MotionLab=()=> <Track scenes={lab}/>;
export const MotionShot=({id}: {id:string})=> <Shot id={id} frames={referenceLength(id)} compact={false}/>;
