import {useVideoConfig} from 'remotion';
import {accent,around,box,Caption,CaptureWindow,Connector,CutPiece,Label,liftSpring,linear,mix,mixRect,OfficialLogo,progress,projectRect,region,Stage,Success,Title,whole,withoutJump} from './Stage';

export type ShotProps = {frame:number;compact?:boolean};

const searchCrop=box(264,206,1159,228);
const phoneCrop=box(0,0,390,844);

export function Opening({frame:f,compact}:ShotProps) {
  const {fps}=useVideoConfig();
  const id='dashboard-montagem';
  const canvas=box(610,81,1270,935);
  const contents=box(0,0,1440,930);
  const camera=progress(f,0,58);
  const slot=mixRect(box(770,214,1170,820),canvas,camera);
  const focuses=['left','mid','right'].map((key,i)=>{
    const area=region(id,key);
    const origin=projectRect(area,contents,slot);
    const lift=(.75+.25*liftSpring(f-8*i,fps))*(1-progress(f,25+6*i,52+6*i));
    return {area, origin, lift, target:mixRect(origin,box(origin.x+(i-1)*38,origin.y-78+i*12,origin.width*1.04,origin.height*1.04),lift)};
  });
  const level=progress(f,64,141);
  return <Stage tone="graphite" frame={f}>
    <svg viewBox="0 0 1920 1080" style={{position:'absolute',inset:0}} aria-hidden="true">
      <path d="M650 0H754L277 1080H193Z" fill="#e92b4923"/>
      <path d="M753 0H775L294 1080H278Z" fill="#e92b4938"/>
    </svg>
    <OfficialLogo slot={box(85,104,133,95)} opacity={progress(f,0,16)}/>
    <Title text="Almox ERP" lines={['Almox','ERP']} frame={f} x={82} y={351} width={523} size={compact?113:128} delay={4}/>
    <Caption text="Gestão de almoxarifado" frame={f} start={18} tone="graphite" x={90} y={652} width={465}/>
    <Label text="Ambiente de demonstração" tone="graphite" y={974}/>
    <CaptureWindow id={id} crop={contents} slot={{...slot,y:slot.y-8*level}} yaw={mix(-14,0,camera)} tilt={mix(8,0,camera)} radius={21}
      opacity={progress(f,1,15)} reveal={progress(f,0,26)} holes={focuses.filter(p=>p.lift>.001).map(p=>p.area)}/>
    {focuses.map((p,i)=><CutPiece key={i} id={id} area={p.area} slot={p.target} amount={p.lift} angle={(i-1)*3} priority={5+i}/>)}
  </Stage>;
}

export function Search({frame:f,compact}:ShotProps) {
  const typing=compact?18:28;
  const selection=compact?69:91;
  const change=selection+18;
  const searching=f<change;
  const id=f<typing?'consulta-inicial':f<typing+12?'consulta-digitando':'consulta-motion';
  const actual='consulta-motion';
  const result=region(actual,'resultado');
  const input=region(actual,'input');
  const rect=box(162,290,1596,545);
  const start=mixRect(box(249,326,1422,486),rect,progress(f,0,35));
  const final=box(138,385,1644,395);
  const detail='produto-localizacoes';
  const detailCrop=box(270,800,1150,170);
  const current=projectRect(result,searchCrop,start);
  const target=projectRect(region(detail),detailCrop,final);
  const open=progress(f,selection,change);
  const resultSweep=progress(f,typing+2,typing+24);
  const resultLift=progress(f,selection-4,selection+2);
  const preview=searching ? 'Busque por nome, código, SKU ou código de barras.' : 'Abra a ficha para ver o saldo por localização.';
  const cursor=searching
    ?f<typing+17?{to:box(input.x+22,input.y,28,input.height),frame:f,arrive:typing-3,click:typing-2,leave:typing+1}
      :{from:box(input.x+22,input.y,28,input.height),to:box(result.x+155,result.y+13,20,14),frame:f,arrive:selection-5,click:selection,leave:selection+8}
    :undefined;
  return <Stage tone="paper" frame={f}>
    <Label text="Consulta rápida"/>
    <Title text="Encontre o material." frame={f}/>
    {searching?<CaptureWindow id={id} crop={searchCrop} slot={start} reveal={progress(f,0,17)} holes={
      f>=typing+12&&f<typing+24?[box(result.x+result.width*resultSweep,result.y,result.width*(1-resultSweep),result.height)]
      :resultLift>0?[result]:[]}
      cursor={resultLift?undefined:cursor}/>
    :<CaptureWindow id={detail} crop={detailCrop} slot={mixRect({...final,y:final.y+14},final,progress(f,change,change+23))}
      reveal={progress(f,change-8,change+14)}/>}
    {searching&&resultLift>0&&<CaptureWindow id={actual} crop={result} slot={mixRect(current,target,open)} radius={mix(0,15,resultLift)} z={7}
      cursor={cursor} opacity={progress(f,selection-4,selection-2)} blur={Math.sin(Math.PI*open)*.7}/>}
    <Caption text={preview} frame={f} start={searching?11:change}/>
  </Stage>;
}

function Parcel({frame:f}:{frame:number}) {
  const enter=progress(f,0,23);
  const yaw=mix(-35,-14,progress(f,6,42));
  const size=346;
  const faces=[
    {key:'front',transform:`translateZ(${size/2}px)`,color:'linear-gradient(135deg,#c7aa81,#aa895e 70%,#98754e)'},
    {key:'right',transform:`rotateY(90deg) translateZ(${size/2}px)`,color:'linear-gradient(135deg,#ae8c62,#806342)'},
    {key:'left',transform:`rotateY(-90deg) translateZ(${size/2}px)`,color:'linear-gradient(90deg,#926e47,#705338)'},
    {key:'top',transform:`rotateX(90deg) translateZ(${size/2}px)`,color:'linear-gradient(145deg,#debf94,#a5835d)'},
    {key:'base',transform:`rotateX(-90deg) translateZ(${size/2}px)`,color:'#8c6948'},
    {key:'back',transform:`rotateY(180deg) translateZ(${size/2}px)`,color:'#94724c'},
  ];
  return <div style={{position:'absolute',left:333,top:322,width:size,height:size,opacity:enter,zIndex:4,transform:`translateY(${(1-enter)*125}px)`}}>
    <div style={{position:'absolute',left:-101,top:378,width:530,height:62,borderRadius:'50%',background:'radial-gradient(ellipse,#29222063,transparent 73%)',filter:'blur(16px)'}}/>
    <div style={{position:'absolute',inset:0,transformStyle:'preserve-3d',transform:`perspective(1600px) rotateX(15deg) rotateY(${yaw}deg) rotateZ(-3deg)`}}>
      {faces.map(face=><div key={face.key} style={{position:'absolute',inset:0,backfaceVisibility:'hidden',transform:face.transform,background:face.color,border:'1px solid #845f38',boxShadow:'inset 0 0 25px #3d210821'}}>
        <div style={{position:'absolute',inset:0,opacity:.21,background:'repeating-linear-gradient(90deg,#72573400 0px,#72573400 3px,#54381275 4px,#72573400 5px)'}}/>
        {(face.key==='front'||face.key==='top')&&<div style={{position:'absolute',left:143,width:62,top:0,bottom:0,background:'linear-gradient(90deg,#70554133,#a0785577,#70554133)',borderInline:'1px solid #87633c55'}}/>}
        {face.key==='front'&&<div style={{position:'absolute',left:141,top:104,width:177,height:185,background:'#f8f3e7',boxShadow:'0 3px 5px #32221444',borderRadius:4,padding:'12px 12px',color:'#302b23',fontSize:15,fontWeight:750}}>
          <div>Etiqueta de demonstração</div>
          <CaptureWindow id="produto-qr-motion" crop={region('produto-qr-motion','qr')} slot={box(24,38,126,126)} radius={0} shadow={false}/>
        </div>}
      </div>)}
    </div>
  </div>;
}

export function QRScene({frame:f,compact}:ShotProps) {
  const collection='produto-qr-motion';
  const revealAt=compact?124:108;
  const after=f>=revealAt;
  const classAt=compact?64:55;
  const scanner=f<classAt?'scanner-mobile':'localizacao-manual';
  const pan=progress(f,revealAt-7,revealAt+14);
  const landing=box(mix(1200,770,pan),220,365,706);
  const intro=progress(f,0,25);
  const phone=mixRect(box(landing.x+84,270,315,650),landing,intro);
  const returnAt=compact?196:191;
  const q=region(collection,'qr');
  const code=region(collection,'codigo');
  const liftA=withoutJump(f,revealAt+13,revealAt+39,returnAt+31,returnAt);
  const liftB=withoutJump(f,revealAt+18,revealAt+45,returnAt+36,returnAt+5);
  const qrAt=projectRect(q,phoneCrop,phone);
  const codeAt=projectRect(code,phoneCrop,phone);
  const showLocation=progress(f,returnAt+26,returnAt+45);
  return <Stage tone="paper" frame={f}>
    <Label text="Etiquetas e localização"/>
    <Title text="Da etiqueta à ficha." frame={f}/>
    {!after&&<Parcel frame={f}/>}
    {!after&&<Connector frame={f} start={17} end={42} path="M 737 551 C 842 551 919 551 1180 551"/>}
    {!after&&<CaptureWindow id={scanner} crop={phoneCrop} slot={phone} radius={31} bezel yaw={mix(-14,0,intro)} angle={mix(6,0,intro)} opacity={intro}/>}
    {after&&<CaptureWindow id={collection} crop={phoneCrop} slot={phone} radius={31} bezel holes={[...(liftA>0?[q]:[]),...(liftB>0?[code]:[])]}/>}
    {after&&<CutPiece id={collection} area={q} slot={mixRect(qrAt,box(359,331,292,292),liftA)} amount={liftA} angle={-5}/>}
    {after&&<CutPiece id={collection} area={code} slot={mixRect(codeAt,box(1190,537,355,110),liftB)} amount={liftB} angle={3}/>}
    {after&&liftA>0&&<Connector frame={f} start={revealAt+15} end={revealAt+44} path="M 649 486 C 704 486 752 468 816 468"/>}
    {showLocation>0&&<CaptureWindow id="produto-localizacoes" crop={around('produto-localizacoes',region('produto-localizacoes'),7,52)} slot={box(1178,657,655,154)} opacity={showLocation} reveal={showLocation}/>}
    <Caption text={after?'A etiqueta corresponde à ficha do material.':f<classAt?'Abra o leitor de etiquetas.':'A consulta manual abre a localização.'} frame={f} start={after?revealAt:f<classAt?7:classAt}/>
  </Stage>;
}

export function Delivery({frame:f,compact}:ShotProps) {
  const review='entrega-revisao';
  const waiting='recebimento-aguardando';
  const unchecked='recebimento-sem-aceite';
  const checked='recebimento-com-aceite';
  const confirmed='recebimento-confirmado';
  const transfer=compact?54:61;
  const checkAt=compact?114:127;
  const confirmAt=compact?148:155;
  const card=region(waiting);
  const cardCrop=around(waiting,card,12,14);
  const reviewCrop=around(review,region(review),22,22);
  const era=f<=transfer?0:f<=checkAt?1:f<=confirmAt?2:3;
  const recipient=era===1?unchecked:era===2?checked:confirmed;
  const checkedSlot=box(1290,209,528,725);
  const detailSlot=box(976,224,747,687);
  const desktop=box(111,357,1006,424);
  const cardAt=projectRect(card,cardCrop,desktop);
  const lift=withoutJump(f,transfer+4,transfer+26,checkAt-3,transfer+33);
  const phoneIn=progress(f,transfer-6,transfer+15);
  const canClick=era===1||era===2;
  const control=canClick?region(recipient,era===1?'check':'button'):region(checked,'button');
  const click=canClick?(era===1?checkAt:confirmAt):undefined;
  const recipientCrop=era===3?around(recipient,region(recipient),9,17):box(0,138,390,614);
  return <Stage tone="graphite" frame={f}>
    <Label text="Entrega e recebimento" tone="graphite"/>
    <Title text="A entrega tem confirmação." size={83} frame={f}/>
    {era===0
      ?<CaptureWindow id={review} crop={reviewCrop} slot={mixRect(box(535,251,850,668),box(465,223,990,711),progress(f,0,35))} reveal={progress(f,0,16)} cursor={{to:region(review,'button'),frame:f,arrive:transfer-6,click:transfer,leave:transfer+1}}/>
      :<>
        {era!==3&&<Connector frame={f} start={transfer+6} end={transfer+34} path="M 1000 563 C 1100 563 1120 520 1194 520 L 1380 520" dark terminal/>}
        {era!==3&&<CaptureWindow id={waiting} crop={cardCrop} slot={desktop} holes={lift>0?[card]:[]}/>}
        {era!==3&&<CutPiece id={waiting} area={card} slot={mixRect(cardAt,box(354,273,848,325),lift)} amount={lift} angle={-2}/>}
        <CaptureWindow id={recipient} crop={recipientCrop} slot={era===3?mixRect(checkedSlot,detailSlot,progress(f,confirmAt,confirmAt+24)):mixRect({...checkedSlot,x:checkedSlot.x+180},checkedSlot,phoneIn)} bezel radius={27}
          tilt={mix(7,0,phoneIn)} yaw={mix(-13,0,phoneIn)} opacity={phoneIn}
          cursor={canClick?{to:control,frame:f,arrive:(click??0)-7,click}:undefined}/>
        {era===3&&<>
          <Success frame={f} start={confirmAt+4} x={145} y={414}/>
          <Title text="Conferência registrada" lines={['Conferência','registrada.']} x={143} y={498} width={750} size={83} frame={f} delay={confirmAt+5}/>
        </>}
      </>}
    <Caption text={era===0?'Operador registra para a conta indicada.':era===3?'O recebimento foi confirmado pela conta destinatária.':era===1?'Entrega aguardando confirmação. O destinatário confere a quantidade.':'O destinatário confirma na própria conta.'}
      frame={f} tone="graphite" start={era===0?8:era===3?confirmAt:transfer}/>
  </Stage>;
}

export function Closing({frame:f,compact}:ShotProps) {
  const steady=compact?45:96;
  const p=progress(f,3,steady);
  const laptop=mixRect(box(913,343,796,548),box(766,340,1005,590),p);
  return <Stage tone="graphite" frame={Math.min(f,steady)}>
    <div style={{position:'absolute',top:204,left:940,width:840,height:635,borderRadius:'50%',background:'radial-gradient(ellipse,#8b193b78,transparent 69%)'}}/>
    <OfficialLogo slot={box(87,204,214,143)} opacity={mix(.34,1,progress(f,0,22))}/>
    <Title text="Almox ERP." frame={f} x={79} y={411} width={720} size={99} delay={10}/>
    <Caption text="Do estoque à operação." frame={f} start={16} x={86} y={557} width={650} tone="graphite"/>
    <div style={{position:'absolute',left:85,top:654,width:200*progress(f,40,steady),height:3,background:accent}}/>
    <div style={{position:'absolute',left:laptop.x-32,top:laptop.y+laptop.height-2,width:laptop.width+64,height:39,
      transform:`rotate(${mix(6,-2,p)}deg)`,background:'linear-gradient(180deg,#6f6871 1%,#25242b 40%,#171619 64%,#5e565e 100%)',
      clipPath:'polygon(3% 0,97% 0,100% 58%,99% 100%,2% 100%,0 58%)',opacity:p,zIndex:3}}/>
    <CaptureWindow id="dashboard" crop={box(0,0,1440,850)} slot={laptop} bezel angle={mix(6,-2,p)} yaw={mix(-23,-7,p)} tilt={mix(8,1,p)} opacity={p} radius={20}/>
    <CaptureWindow id="produto-mobile" crop={whole('produto-mobile')} slot={mixRect(box(1580,166,298,645),box(1495,207,320,700),p)} bezel angle={mix(12,5,p)} yaw={mix(-17,-7,p)} opacity={p} radius={32} z={4}/>
  </Stage>;
}
