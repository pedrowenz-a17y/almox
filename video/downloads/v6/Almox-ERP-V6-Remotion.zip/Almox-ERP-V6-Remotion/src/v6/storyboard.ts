export type Screen={asset:string;view?:'screen'|'focus';cursor?:string};
export type Beat={frame:number;caption:string;screens:Screen[]};
export type Scene={id:string;title:string;frames:number;beats:Beat[]};
const wide=(asset:string):Screen=>({asset,view:'screen'});
const close=(asset:string,cursor?:string):Screen=>({asset,view:'focus',cursor});
const beat=(frame:number,caption:string,...screens:Screen[]):Beat=>({frame,caption,screens});
export const full:Scene[]=[
  {id:'Abertura',title:'Gestão de almoxarifado',frames:150,beats:[beat(0,'Painel do Almox ERP',wide('dashboard'))]},
  {id:'Consulta',title:'Encontre o material',frames:180,beats:[
    beat(0,'Consulta rápida',close('consulta-inicial','input')),
    beat(33,'A lista acompanha o texto digitado',close('consulta-digitando','input')),
    beat(68,'Selecione a ficha do material',close('consulta-resultado','resultado')),
    beat(115,'A ficha mostra saldo por localização',close('produto-localizacoes'))]},
  {id:'QR',title:'Da etiqueta à localização',frames:240,beats:[
    beat(0,'Leitor do Almox com a câmera fechada',wide('scanner-mobile')),
    beat(72,'A localização abre após a consulta',wide('localizacao-manual')),
    beat(144,'Etiqueta demonstrativa na ficha do material',close('produto-localizacoes'),wide('etiqueta-mobile'))]},
  {id:'Assistente',title:'Consulte o assistente',frames:300,beats:[
    beat(0,'Assistente do almoxarifado em modo local',close('assistente-local')),
    beat(115,'Orientação sobre etiquetas sem consultar saldos',close('assistente-resposta'))]},
  {id:'Reposicao',title:'Planeje a reposição',frames:180,beats:[beat(0,'Disponível, mínimo, em compra e meta',close('reposicao'))]},
  {id:'Inventario',title:'Revise a contagem',frames:180,beats:[
    beat(0,'Quem contou não aprova a própria contagem',close('inventario-autor')),
    beat(74,'Outra pessoa autorizada revisa a divergência',close('inventario-revisor')),
    beat(126,'O estado muda após a aprovação do revisor',close('inventario-aprovado'))]},
  {id:'Entrega',title:'Confirme o recebimento',frames:210,beats:[
    beat(0,'Operador revisa a entrega para a conta indicada',close('entrega-revisao','button')),
    beat(66,'O destinatário confere a quantidade e confirma',close('recebimento-aguardando'),wide('recebimento-consentimento')),
    beat(148,'A tela do destinatário registra a confirmação',wide('recebimento-confirmado'))]},
  {id:'Turno',title:'Passe o turno',frames:180,beats:[
    beat(0,'A responsabilidade atual permanece até o aceite',close('turno-aguardando')),
    beat(65,'A pessoa indicada aceita com a própria conta',close('turno-aceitar','button')),
    beat(123,'O novo titular aparece após o aceite',close('turno-assumido'))]},
  {id:'CSV',title:'Confira o arquivo',frames:210,beats:[
    beat(0,'Conciliação com ERP: associe colunas e critérios',close('csv-importar')),
    beat(66,'Veja diferenças e linhas que conferem na prévia',close('csv-previa')),
    beat(131,'Outra pessoa autorizada registra o parecer',close('csv-revisao','button'))]},
  {id:'Alertas',title:'Acompanhe os alertas',frames:180,beats:[
    beat(0,'Avisos e filtros na Central de alertas',close('alertas')),
    beat(95,'O histórico registra sua leitura',close('alertas-leituras'))]},
  {id:'Gerencial',title:'Compare as unidades',frames:180,beats:[
    beat(0,'Visão da operação nas unidades autorizadas',close('gerencial')),
    beat(101,'A comparação também está no celular',close('gerencial'),wide('gerencial-mobile'))]},
  {id:'Encerramento',title:'Almox ERP',frames:150,beats:[beat(0,'Do estoque à operação',wide('dashboard'),wide('produto-mobile'))]},
];
const byId=(id:string):Scene=>{
  const scene=full.find(item=>item.id===id);
  if(!scene)throw Error(id);
  return scene;
};
export const launch:Scene[]=[
  {...byId('Abertura'),frames:90},
  {...byId('Consulta'),frames:120,beats:[byId('Consulta').beats[0],{...byId('Consulta').beats[2],frame:37},{...byId('Consulta').beats[3],frame:75}]},
  {...byId('QR'),frames:120,beats:[byId('QR').beats[0],{...byId('QR').beats[1],frame:50}]},
  {...byId('Assistente'),frames:120,beats:[byId('Assistente').beats[0],{...byId('Assistente').beats[1],frame:47}]},
  {...byId('Inventario'),frames:120,beats:[byId('Inventario').beats[0],{...byId('Inventario').beats[1],frame:45},{...byId('Inventario').beats[2],frame:82}]},
  {...byId('Entrega'),frames:180,beats:[byId('Entrega').beats[0],{...byId('Entrega').beats[1],frame:55},{...byId('Entrega').beats[2],frame:122}]},
  {...byId('Alertas'),frames:59,beats:[byId('Alertas').beats[0]]},
  {...byId('Gerencial'),frames:61,beats:[byId('Gerencial').beats[0]]},
  {id:'Assinatura',title:'O almoxarifado em movimento',frames:90,beats:[beat(0,'Do estoque à operação')]},
  {...byId('Encerramento'),frames:90},
];
export const duration=(scenes:Scene[])=>scenes.reduce((total,scene)=>total+scene.frames,0);
