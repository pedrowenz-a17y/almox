export type Rect={x:number;y:number;width:number;height:number};
export type Viewport={width:number;height:number};
const clamp=(x:number,min:number,max:number)=>Math.min(max,Math.max(min,x));

export function focusCrop(view:Viewport,focus:Rect,margin=36):Rect {
  const width=Math.min(view.width,Math.max(Math.min(645,view.width),focus.width+margin*2));
  const height=Math.min(view.height,Math.max(Math.min(320,view.height),focus.height+margin*2));
  return {
    x:clamp(focus.x+(focus.width-width)/2,0,view.width-width),
    y:clamp(focus.y+(focus.height-height)/2,0,view.height-height),
    width,height,
  };
}

export function fitCapture(crop:Rect,target:Rect) {
  const scale=Math.min(target.width/crop.width,target.height/crop.height);
  const width=crop.width*scale,height=crop.height*scale;
  return {x:target.x+(target.width-width)/2,y:target.y+(target.height-height)/2,width,height,scale};
}

export function mapCapturePoint(source:{x:number;y:number},crop:Rect,target:Rect) {
  if(source.x<crop.x||source.y<crop.y||source.x>crop.x+crop.width||source.y>crop.y+crop.height)return null;
  const fitted=fitCapture(crop,target);
  return {x:fitted.x+(source.x-crop.x)*fitted.scale,y:fitted.y+(source.y-crop.y)*fitted.scale};
}

export const centerOf=({x,y,width,height}:Rect)=>({x:x+width/2,y:y+height/2});

export const stageBody={x:630,y:170,width:1202,height:760};
export function screenSlots(count:number):Rect[]{
  if(count===1)return [stageBody];
  return [{x:630,y:200,width:790,height:700},{x:1444,y:162,width:388,height:776}];
}
