import {AbsoluteFill,Img,Sequence,staticFile,useCurrentFrame} from 'remotion';
import {ScreenCapture} from './Assets';
import {screenSlots} from './geometry';
import {full,launch,type Scene} from './storyboard';
import '../film.css';

export const BaseScene=({scene}:{scene:Scene})=>{
  const frame=useCurrentFrame();
  const current=scene.beats.findLast(beat=>beat.frame<=frame)??scene.beats[0];
  const slots=screenSlots(current.screens.length);
  return <AbsoluteFill style={{background:'#f5f1ef',color:'#211921',fontFamily:'DM Sans, Arial'}}>
    <Img src={staticFile('etapa1/uca-oficial.png')} style={{position:'absolute',left:88,top:56,width:86,height:60,objectFit:'contain'}}/>
    <div style={{position:'absolute',left:88,top:345,width:494}}>
      <h1 style={{fontFamily:'Manrope, Arial',fontWeight:800,fontSize:69,lineHeight:1.02,letterSpacing:-4,margin:0}}>{scene.title}</h1>
      <div style={{marginTop:29,width:78,height:5,background:'#c30031'}}/>
      <p style={{fontSize:31,lineHeight:1.3,marginTop:29,color:'#5c5059'}}>{current.caption}</p>
    </div>
    {current.screens.map((screen,index)=><ScreenCapture key={screen.asset+index} assetId={screen.asset} slot={slots[index]} mode={screen.view} cursor={screen.cursor}/>)}
    <div style={{position:'absolute',left:88,bottom:58,fontSize:20,color:'#655864'}}>Almox ERP · Dados fictícios</div>
  </AbsoluteFill>;
};
const BaseTimeline=({scenes}:{scenes:Scene[]})=>{
  let start=0;
  return <AbsoluteFill>{scenes.map(scene=>{
    const from=start;
    start+=scene.frames;
    return <Sequence key={scene.id} name={scene.title} from={from} durationInFrames={scene.frames}><BaseScene scene={scene}/></Sequence>;
  })}</AbsoluteFill>;
};
export const FullBase=()=> <BaseTimeline scenes={full}/>;
export const LaunchBase=()=> <BaseTimeline scenes={launch}/>;
