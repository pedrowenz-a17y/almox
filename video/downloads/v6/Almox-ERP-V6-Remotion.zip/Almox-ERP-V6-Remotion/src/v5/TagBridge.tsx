import {tagSource,tagTarget} from './Interactions';
import {MaterialTag,TravelingCard,tween} from './motion';

export const TagBridge=({f,start,end}:{f:number;start:number;end:number})=>
  <TravelingCard from={tagSource} to={tagTarget} p={tween(f,start,end-1)} arc={114} tilt={-14}>
    <MaterialTag qr/>
  </TravelingCard>;
