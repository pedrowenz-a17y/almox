import {ArrowDown, ArrowRight, Bell, Boxes, CalendarClock, ClipboardList, FileSpreadsheet, ListChecks, Package, RefreshCw, ShoppingCart, TriangleAlert} from 'lucide-react';
import {Dashboard} from '../screens';
import {Badge, CheckMark, Chip, Enter, HeroCard, Logo, Panel, Phone, Progress, Stage, Title, TravelingCard, box, cycle, line, mix, tween, useTime, type Rect} from './motion';

type Shot={seconds:number;compact?:boolean};

export const Restock=({seconds}:Shot)=>{
  const t=useTime(seconds);
  const focus=tween(t,.39,.59);
  const products=[['Correia em V A42','4 de 10','Comprar 6 un.'],['Rolamento 6205','16 de 12','Saldo adequado'],['Filtro hidráulico','8 de 6','Saldo adequado']];
  return <Stage area="Reposição" palette="ink">
    <Title lines={['Antecipe','a reposição.']} t={t} style={{top:336}} detail="Compare o saldo com o mínimo cadastrado."/>
    {products.map(([name,value,status],i)=>{
      const n=i===0?focus:0;
      const start=.08+i*.075;
      return <Enter key={name} t={t} start={start} end={start+.16} tilt={i===0?-4:3} style={box([762-n*65,241+i*205+n*6,898+n*54,163+n*32])}>
        <HeroCard style={{opacity:i===0?1:1-focus*.28,borderColor:n>.7?'#e58aa5':undefined}}>
          <div className="v5-card-top"><Chip icon={<ShoppingCart size={27}/>}><b>{name}</b><small>{value} un.</small></Chip><Badge tone={i===0?'amber':'green'}>{status}</Badge></div>
          <div style={{marginTop:19}}><Progress p={tween(t,start+.11,start+.36)*(i===0?.4:i===1?.88:.76)}/></div>
        </HeroCard>
      </Enter>;
    })}
  </Stage>;
};

const countCards=[
  {icon:ClipboardList,label:'Conte.',hint:'Saldo registrado',number:120},
  {icon:RefreshCw,label:'Compare.',hint:'Contagem física',number:118},
  {icon:ListChecks,label:'Revise.',hint:'Unidades a menos',number:2},
];
export const Inventory=({seconds,compact}:Shot)=>{
  const t=useTime(seconds);
  const regroup=tween(t,.74,.96);
  const compare=tween(t,.30,.60);
  return <Stage area={compact?'Reposição e inventário':'Inventário'}>
    <Title lines={compact?['Organize o estoque.']:['Conte. Compare. Revise.']} center t={t} style={{top:160}} detail={compact?'Acompanhe o saldo e revise a contagem física.':'Compare o saldo registrado com a conferência física.'}/>
    <div className="v5-inventory-bed" style={{...box([352,403,1216,376]),opacity:regroup*.68}}/>
    {countCards.map(({icon:Icon,label,hint,number},i)=>{
      const start=.14+i*.075;
      const p=tween(t,start,start+.16);
      const value=Math.round(mix(i===2?0:100,number,compare));
      return <Enter key={label} t={t} start={start} end={start+.15} tilt={(i-1)*10} move={96} style={box([mix(340+i*425,378+i*403,regroup),mix(438+i*29,434,regroup),365,289])}>
        <HeroCard style={{borderColor:i===2&&compare>.75?'#cb7794':undefined}}>
          <div className="v5-card-top"><span className="v5-icon"><Icon size={27}/></span><span style={{color:'#23794b'}}><CheckMark p={tween(t,start+.23,start+.32)} size={28}/></span></div>
          <h3 style={{marginTop:15}}>{label}</h3><div className="v5-number">{i===2&&compare>.1&&<ArrowDown size={32}/>} {p>.3?value:'—'}</div><small className="v5-hint">{hint}</small>
        </HeroCard>
      </Enter>;
    })}
    <Enter t={t} start={.25} style={box([491,783,938,7])}><Progress p={line(t,.26,.78)}/></Enter>
    <Enter t={t} start={.59} style={{...box([511,822,900,65]),textAlign:'center'}}><Badge tone="amber">{compact?'Reposição: acompanhe itens abaixo do mínimo':'Divergência encaminhada para revisão manual'}</Badge></Enter>
  </Stage>;
};

export const Shift=({seconds}:Shot)=>{
  const t=useTime(seconds), transfer=tween(t,.43,.72);
  return <Stage area="Passagem de turno">
    <Title lines={['O próximo turno','segue informado.']} t={t} center detail="Pendências, prazo e responsabilidade continuam visíveis."/>
    <Enter t={t} start={.08} style={box([218,436,604,400])}><HeroCard><Chip icon={<CalendarClock size={32}/>}><b>Turno A</b><small>Ocorrências registradas</small></Chip>
      <div className="v5-list" style={{marginTop:29}}>{['Registrar saldo conferido','Revisar solicitação de reposição'].map((label,i)=><Enter key={label} t={t} start={.22+i*.07} move={17}><div className="v5-row"><span>{label}</span><Badge tone="green">Registrado</Badge></div></Enter>)}</div>
    </HeroCard></Enter>
    <Enter t={t} start={.24} style={box([1094,436,604,400])}><HeroCard><Chip icon={<CalendarClock size={32}/>}><b>Turno B</b><small>Revisão do próximo turno</small></Chip>
      <div style={{...box([22,290,555,74]),opacity:tween(t,.69,.82)}}><Badge tone="amber">Prazo de revisão · amanhã, 08h</Badge></div>
    </HeroCard></Enter>
    <span style={{...box([920,583,60,60]),color:'#b0204d',opacity:tween(t,.37,.49)}}><ArrowRight size={56}/></span>
    <TravelingCard from={[241,675,557,85]} to={[1119,566,552,85]} arc={73} tilt={6} p={transfer} style={{opacity:tween(t,.34,.44)}}>
      <div className="v5-task v5-row"><span>Conferir localização A-03</span><Badge tone="amber">Pendente</Badge></div>
    </TravelingCard>
  </Stage>;
};

export const Csv=({seconds}:Shot)=>{
  const t=useTime(seconds), panel=tween(t,.13,.34);
  const data=[['Rolamento 6205','16','16','Confere'],['Correia em V A42','4','6','Divergência'],['Filtro hidráulico','8','8','Confere']];
  return <Stage palette="ink" area="Conferência CSV">
    <Title lines={['Compare.','Depois revise.']} t={t} size={82} style={{top:310}} detail="Cruze o arquivo com o saldo do Almox."/>
    <Enter t={t} start={.11} style={box([674,266,1116,591])} move={30}>
      <Panel title="Conferência de estoque" subtitle="Prévia da conferência" style={{height:'100%'}}><div className="v5-table-head v5-csv-grid" style={{opacity:tween(t,.36,.54)}}><span>Material</span><span>Almox</span><span>CSV</span><span>Situação</span></div></Panel>
    </Enter>
    <TravelingCard from={[722,454,594,141]} to={[722,425,386,64]} p={panel} arc={30} style={{opacity:tween(t,.04,.16)}}>
      <div className="v5-file" style={{fontSize:mix(33,22,panel)}}><FileSpreadsheet size={mix(53,24,panel)}/> estoque_demo.csv</div>
    </TravelingCard>
    {data.map(([name,sys,file,status],i)=>{
      const p=tween(t,.37+i*.075,.63+i*.075);
      return <TravelingCard key={name} from={[729+i*22,488+i*45,483,60]} to={[710,535+i*81,1044,72]} p={p} arc={25} style={{opacity:tween(t,.34+i*.06,.46+i*.06)}}>
        <div className="v5-csv-grid v5-csv-row" style={{borderColor:i===1&&p>.8?'#e3a75d':undefined}}><b>{name}</b><span style={{opacity:p}}>{sys}</span><span style={{opacity:p}}>{file}</span><span style={{opacity:p}}><Badge tone={i===1?'amber':'green'}>{status}</Badge></span></div>
      </TravelingCard>;
    })}
  </Stage>;
};

const notifications=[
  {title:'Conferir localização A-03',kind:'Inventário',tone:'red',time:'Vencido'},
  {title:'Confirmar devolução',kind:'Equipe de almoxarifado',tone:'amber',time:'Hoje'},
  {title:'Revisar pedido de compra',kind:'Equipe de compras',tone:'muted',time:'Nesta semana'},
] as const;

export const Alerts=({seconds,compact}:Shot)=>{
  const t=useTime(seconds), pull=cycle(t,.43,.58,.74,.94);
  const align=tween(t,.19,.36);
  const src:Rect=[760,398,989,107];
  return <Stage area={compact?'Alertas e unidades':'Central de alertas'} palette={compact?'ink':'paper'}>
    <Title lines={['Veja o que','pede atenção.']} t={t} style={{top:303}} detail="Acompanhe os prazos e situações em aberto."/>
    <Enter t={t} start={0} end={.16} style={box([722,250,1066,583])}><Panel title="Central de alertas" subtitle="Unidade A · Em aberto" style={{height:'100%'}}/></Enter>
    {notifications.map(({title,kind,tone,time},i)=>{
      const origin:Rect=[src[0]+(1-align)*(i-1)*44,src[1]+i*122,src[2],src[3]];
      const p=i===0?pull:0;
      return <TravelingCard key={title} from={origin} to={[654,495,996,169]} p={p} arc={29} tilt={-4} style={{opacity:tween(t,.10+i*.075,.24+i*.075),zIndex:p>.08?14:12}}>
        <div className="v5-notice" style={{boxShadow:p>.05?'0 17px 25px #26173d50':undefined}}>
          <Chip icon={i===0?<TriangleAlert size={27}/>:<Bell size={27}/>}><b>{title}</b><small>{kind}</small></Chip>
          <Badge tone={tone}>{time}</Badge>
          {p>.72&&<span className="v5-notice-more">Acompanhamento em aberto {compact?'· Unidade A · 1 revisão pendente':''}</span>}
        </div>
      </TravelingCard>;
    })}
    {compact&&<Enter t={t} start={.66} style={{...box([760,786,470,70]),zIndex:15}}><Badge tone="green">Unidade A · 1 inventário em revisão</Badge></Enter>}
  </Stage>;
};

export const Units=({seconds}:Shot)=>{
  const t=useTime(seconds), dock=tween(t,.42,.69), camera=tween(t,.67,.93);
  const phone=tween(t,.67,.89);
  return <Stage area="Visão gerencial">
    <Title lines={['Compare as unidades.']} t={t} center detail="Recebimentos, pendências e inventários em revisão."/>
    <div style={{...box([430-camera*147,382+camera*30,1002,484]),scale:1-camera*.10,transformOrigin:'top left'}}>
      <Panel title="Visão da operação" subtitle="Unidades autorizadas" style={{height:'100%'}}>
        <div className="v5-table-head" style={{marginTop:14,opacity:dock}}><span>Filas operacionais</span></div>
      </Panel>
    </div>
    <div className="v5-laptop-base" style={{...box([243,840,974,15]),opacity:camera}}/>
    {[['Unidade A','2','1'],['Unidade B','1','2']].map(([unit,pending,inventory],i)=>{
      const a:Rect=[585+i*549,465,457,214];
      const b:Rect=[462+i*472-camera*146,576+camera*9,432-camera*53,170-camera*19];
      return <TravelingCard key={unit} from={a} to={b} p={dock} arc={29} tilt={(i-.5)*10} style={{opacity:tween(t,.12+i*.07,.32+i*.07)}}>
        <HeroCard style={{padding:19}}><b style={{fontSize:25}}>{unit}</b><div className="v5-unit-grid"><span><strong>{pending}</strong> recebimentos</span><span><strong>{inventory}</strong> em revisão</span></div></HeroCard>
      </TravelingCard>;
    })}
    <Phone title="Visão da operação" style={{...box([1321,386,287,498]),opacity:phone,rotate:`${6+6*(1-phone)}deg`,translate:`${(1-phone)*176}px 0`}}><div className="v5-phone-tiles"><div className="v5-dash-tile" style={{height:118}}><Boxes size={26}/><span>Unidade A</span><b>2</b></div></div></Phone>
  </Stage>;
};

export const Statement=({seconds}:Shot)=>{
  const t=useTime(seconds), fill=tween(t,.52,.70);
  return <Stage palette="red">
    <Title lines={['Menos etapas dispersas.','Mais controle.']} center t={t} style={{top:369}}/>
    <div style={{...box([617,643,686,8]),opacity:fill}}><Progress p={fill}/></div>
  </Stage>;
};

export const Close=({seconds,compact,settled}:Shot & {settled?:boolean})=>{
  const time=useTime(seconds);
  const t=settled?1:time, settle=tween(t,.08,.45), reveal=tween(t,.26,.59);
  const baseY=compact?390:362;
  return <Stage palette="paper">
    <div style={{...box([220+(1-settle)*48,baseY+70+(1-settle)*84,464,273]),opacity:tween(t,0,.18)}}>
      <div style={{transform:'scale(.40)',transformOrigin:'top left'}}><Dashboard/></div>
      <div className="v5-laptop-base" style={{top:268}}/>
    </div>
    <Phone title="Materiais" style={{...box([661+(1-settle)*106,baseY-3+(1-settle)*82,215,377]),rotate:`${9*(1-settle)+6}deg`,opacity:tween(t,.03,.20)}}>
      <div className="v5-phone-tiles"><div className="v5-compact-product"><Package size={23}/> Rolamento 6205 <small>16 disponíveis</small></div></div>
    </Phone>
    {t<.58&&<TravelingCard from={[745,338,263,90]} to={[681,baseY+143,163,66]} p={tween(t,.12,.57)} arc={52} style={{opacity:cycle(t,.06,.15,.52,.58)}}>
      <div className="v5-file" style={{fontSize:18}}><Package size={21}/> MAT-042</div>
    </TravelingCard>}
    <div className="v5-end-lockup" style={{...box([1029,386,734,339]),translate:`0 ${(1-reveal)*22}px`,opacity:reveal}}>
      <Logo width={126}/><h2>Almox ERP</h2><p>Do estoque à operação.</p>
    </div>
  </Stage>;
};
