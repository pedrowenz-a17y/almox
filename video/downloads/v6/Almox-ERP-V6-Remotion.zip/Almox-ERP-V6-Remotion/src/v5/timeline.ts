import {Access, AssistantShot, DeliveryShot, QrShot, SearchShot} from './Interactions';
import {Alerts, Close, Csv, Inventory, Restock, Shift, Statement, Units} from './Operations';

export const FPS=30;
export type Cut={name:string;seconds:number;component:typeof Access;compact?:boolean};
export const full:Cut[]=[
  {name:'Acesso',seconds:5,component:Access},
  {name:'Busca',seconds:6,component:SearchShot},
  {name:'QR Code',seconds:8,component:QrShot},
  {name:'Assistente',seconds:10,component:AssistantShot},
  {name:'Reposição',seconds:6,component:Restock},
  {name:'Inventário',seconds:6,component:Inventory},
  {name:'Entrega',seconds:7,component:DeliveryShot},
  {name:'Turno',seconds:6,component:Shift},
  {name:'CSV',seconds:7,component:Csv},
  {name:'Alertas',seconds:6,component:Alerts},
  {name:'Unidades',seconds:6,component:Units},
  {name:'Marca',seconds:5,component:Close},
];
export const launch:Cut[]=[
  {name:'Acesso',seconds:3,component:Access,compact:true},
  {name:'Busca',seconds:4,component:SearchShot,compact:true},
  {name:'QR Code',seconds:4,component:QrShot,compact:true},
  {name:'Assistente',seconds:4,component:AssistantShot,compact:true},
  {name:'Estoque',seconds:4,component:Inventory,compact:true},
  {name:'Entrega',seconds:6,component:DeliveryShot,compact:true},
  {name:'Alertas e unidades',seconds:4,component:Alerts,compact:true},
  {name:'Mensagem',seconds:3,component:Statement,compact:true},
  {name:'Marca',seconds:3,component:Close,compact:true},
];
export const prototype:Cut[]=[
  {name:'Busca',seconds:3.8,component:SearchShot,compact:true},
  {name:'QR Code',seconds:4.2,component:QrShot,compact:true},
  {name:'Entrega',seconds:5,component:DeliveryShot,compact:true},
];
export const plan=(cuts:Cut[])=>{
  let from=0;
  return cuts.map(cut=>{
    const duration=Math.round(cut.seconds*FPS);
    const result={...cut,duration,from};
    from+=duration;
    return result;
  });
};
export const duration=(cuts:Cut[])=>plan(cuts).reduce((total,cut)=>total+cut.duration,0);
