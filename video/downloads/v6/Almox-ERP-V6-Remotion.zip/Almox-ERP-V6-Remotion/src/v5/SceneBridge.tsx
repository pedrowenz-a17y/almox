import {mix,tween} from './motion';

export const SceneBridge=({frame}:{frame:number})=>{
  if(frame < -9 || frame > 11)return null;
  const x=frame<0?mix(2100,0,tween(frame,-9,0)):mix(0,-2160,tween(frame,0,11));
  return <div aria-hidden="true" style={{position:'absolute',inset:'-40px -90px',zIndex:50,background:'#c60535',transform:`translateX(${x}px) skewX(-8deg)`}}/>;
};
