import {AbsoluteFill, getRemotionEnvironment, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {SceneBridge} from './SceneBridge';
import {TagBridge} from './TagBridge';
import {full,launch,plan,prototype,type Cut} from './timeline';
import {Close} from './Operations';
import manifest from './narration.json';

const SceneTrack=({cuts}:{cuts:Cut[]})=>{
  const f=useCurrentFrame();
  const scenes=plan(cuts);
  const search=scenes.find(c=>c.name==='Busca');
  const qr=scenes.find(c=>c.name==='QR Code');
  const start=search?search.from+Math.ceil(search.duration*.92):0;
  const end=qr?qr.from+Math.floor(qr.duration*.075)+1:0;
  const transition=scenes.find(c=>c.name===(cuts===launch?'Marca':cuts===full?'Entrega':''));
  return <AbsoluteFill>
    {scenes.map(({component:Scene,name,from,duration,seconds,compact})=>
      <Sequence key={name} name={name} from={from} durationInFrames={duration}><Scene seconds={seconds} compact={compact}/></Sequence>)}
    {search&&qr&&f>=start&&f<end&&<TagBridge f={f} start={start} end={end}/>}
    {transition&&<SceneBridge frame={f-transition.from}/>}
  </AbsoluteFill>;
};
type FullProps={audioMode?:'music-only'|'narrated'};
export const FullV5=({audioMode='music-only'}:FullProps)=>{
  const pending=audioMode==='narrated'&&manifest.segments.some(segment=>segment.status!=='validated');
  if(pending&&getRemotionEnvironment().isRendering) {
    throw Error('Narrated requer os 12 clipes medidos. Rode npm run narration:validate.');
  }
  return <><SceneTrack cuts={full}/><Audio src={staticFile(audioMode==='narrated'&&!pending?'audio/v5-narrated.m4a':'audio/v5-full.m4a')}/>
    {pending&&<div style={{position:'absolute',bottom:92,left:88,zIndex:60,background:'#522236',color:'#fff',font:'700 25px Arial',padding:'14px 21px',borderRadius:11}}>Prévia incompleta · narração pendente</div>}</>;
};
export const NarratedV5=()=> <FullV5 audioMode="narrated"/>;
export const LaunchV5=()=> <><SceneTrack cuts={launch}/><Audio src={staticFile('audio/v5-launch.m4a')}/></>;
export const PrototypeV5=()=> <SceneTrack cuts={prototype}/>;
export const ThumbnailV5=()=> <Close seconds={5} settled/>;
