import type {CSSProperties, ReactNode} from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Search, MousePointer2, ArrowUpRight, Package, MapPin, Bell, ScanLine} from 'lucide-react';
import './v5.css';

const clamp = {extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const tween = (t:number,a:number,b:number) => interpolate(t,[a,b],[0,1],{...clamp,easing:Easing.bezier(.36,.02,.18,1)});
export const line = (t:number,a:number,b:number) => interpolate(t,[a,b],[0,1],clamp);
export const mix = (a:number,b:number,p:number) => a+(b-a)*p;
export const cycle = (t:number,a:number,b:number,c:number,d:number) => tween(t,a,b)*(1-tween(t,c,d));
export const typed = (value:string,t:number,a:number,b:number) => value.slice(0,Math.floor(value.length*line(t,a,b)));
export const useTime = (seconds:number) => {
  const frame=useCurrentFrame();
  const {fps}=useVideoConfig();
  return Math.max(0,Math.min(1,frame/(fps*seconds)));
};

export type Palette = 'paper'|'ink'|'red';
export type Rect = [x:number,y:number,w:number,h:number];
export const box = ([left,top,width,height]:Rect):CSSProperties => ({position:'absolute',left,top,width,height});
export const rectAt = (a:Rect,b:Rect,p:number):Rect => [mix(a[0],b[0],p),mix(a[1],b[1],p),mix(a[2],b[2],p),mix(a[3],b[3],p)];

export const Logo = ({width=56}:{width?:number}) => <Img className="v5-logo" style={{width}} src={staticFile('brand/uca.png')}/>;
export const Stage = ({children,palette='paper',area}:{children:ReactNode;palette?:Palette;area?:string}) =>
  <AbsoluteFill className={`v5 v5-${palette}`}>
    <div className="v5-header"><div><Logo/><b>Almox ERP</b></div>{area && <span>{area}</span>}</div>
    {children}
    {area && <div className="v5-footer"><span>U.C.A.</span><span>Dados demonstrativos</span></div>}
  </AbsoluteFill>;

export const Title = ({lines,t,center=false,style,detail,size}:{lines:string[];t:number;center?:boolean;style?:CSSProperties;detail?:string;size?:number}) =>
  <div className={`v5-title ${center?'v5-centered':''}`} style={style}>
    <h1 style={{fontSize:size}}>{lines.map((s,i)=><div key={s} className="v5-cliptext"><span style={{translate:`0 ${(1-tween(t,.015+i*.028,.112+i*.028))*112}%`}}>{s}</span></div>)}</h1>
    {detail && <p style={{opacity:tween(t,.10,.24)}}>{detail}</p>}
  </div>;
export const Enter = ({t,start=0,end=start+.14,style,children,move=40,tilt=0}:{
  t:number;start?:number;end?:number;style?:CSSProperties;children:ReactNode;move?:number;tilt?:number;
}) => {
  const p=tween(t,start,end);
  return <div style={{...style,opacity:p,translate:`0 ${(1-p)*move}px`,rotate:`${(1-p)*tilt}deg`}}>{children}</div>;
};
export const HeroCard = ({children,style,className=''}:{children:ReactNode;style?:CSSProperties;className?:string}) =>
  <div className={`v5-card ${className}`} style={style}>{children}</div>;
export const Badge = ({children,tone='muted'}:{children:ReactNode;tone?:'muted'|'green'|'amber'|'red'}) =>
  <span className={`v5-badge v5-${tone}-badge`}>{children}</span>;
export const Chip = ({icon,children}:{icon:ReactNode;children:ReactNode}) =>
  <div className="v5-chip"><span>{icon}</span><div>{children}</div></div>;
export const CheckMark = ({p,size=22}:{p:number;size?:number}) =>
  <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 12.8 9.5 18 19.5 6.5" pathLength="1" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1-p}/></svg>;
export const Progress = ({p}:{p:number}) => <div className="v5-progress"><i style={{scale:`${p} 1`}}/></div>;
export const Cursor = ({x,y,t,click,show=1}:{x:number;y:number;t:number;click:number;show?:number}) => {
  const pulse=line(t,click,click+.075);
  return <div className="v5-cursor" style={{left:x,top:y,opacity:show,scale:t>=click&&pulse<.33?.86:1}}>
    {pulse>0&&pulse<1&&<i style={{scale:.5+pulse*1.8,opacity:1-pulse}}/>}
    <MousePointer2 size={38} strokeWidth={1.65} fill="#1a1518" stroke="white"/>
  </div>;
};
export const Button = ({children,pressed=0,quiet=false}:{children:ReactNode;pressed?:number;quiet?:boolean}) =>
  <span className={`v5-button ${quiet?'v5-quiet':''}`} style={{scale:1-pressed*.052}}>{children}</span>;
export const SearchField = ({text,focus,caret=false}:{text:string;focus:number;caret?:boolean}) =>
  <div className="v5-search" style={{borderColor:focus>.6?'#d90032':undefined}}><Search size={32}/><span>{text||'Buscar por material ou código'}{caret&&<i/>}</span></div>;
export const QRMark = ({size=120}:{size?:number}) => <Img src={staticFile('brand/qr-demo.png')} style={{width:size,height:size,objectFit:'contain'}}/>;
export const MaterialTag = ({style,qr=false}:{style?:CSSProperties;qr?:boolean}) =>
  <div className="v5-tag" style={style}>{qr?<QRMark size={70}/>:<div className="v5-icon"><ScanLine size={27}/></div>}<div><b>A-03-02</b><small>Localização · MAT-042</small></div></div>;
export const Material = ({detail=false}:{detail?:boolean}) =>
  <><Chip icon={<Package size={29}/>}><b>Rolamento 6205</b><small>MAT-042 · Corredor A</small></Chip>
  {detail&&<div className="v5-material-data"><span><MapPin size={22}/> Prateleira 03</span><Badge tone="green">16 disponíveis</Badge></div>}</>;
export const Phone = ({title,children,style}:{title:string;children:ReactNode;style?:CSSProperties}) =>
  <div className="v5-phone" style={style}><div className="v5-phone-tip"/><div className="v5-phone-nav"><Logo width={34}/><b>Almox ERP</b><Bell size={19}/></div><h3>{title}</h3>{children}<div className="v5-home"/></div>;
export const Panel = ({title,subtitle,children,style}:{title:string;subtitle?:string;children?:ReactNode;style?:CSSProperties}) =>
  <div className="v5-panel" style={style}>
    <div className="v5-panel-bar"><i/><i/><i/><span>Almox ERP</span><ArrowUpRight size={17}/></div>
    <div className="v5-panel-body"><h3>{title}</h3>{subtitle&&<p>{subtitle}</p>}{children}</div>
  </div>;

export const TravelingCard = ({from,to,p,children,arc=0,tilt=0,style}:{
  from:Rect;to:Rect;p:number;children:ReactNode;arc?:number;tilt?:number;style?:CSSProperties;
}) => {
  const curve=Math.sin(Math.PI*p);
  return <div style={{...box(rectAt(from,to,p)),zIndex:12,translate:`0 ${-arc*curve}px`,rotate:`${tilt*curve}deg`,...style}}>{children}</div>;
};
