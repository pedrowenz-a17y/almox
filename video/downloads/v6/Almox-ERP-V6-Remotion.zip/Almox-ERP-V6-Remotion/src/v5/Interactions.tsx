import {ArrowRight, ArrowUp, Bell, Boxes, Check, ClipboardCheck, MapPin, Package, QrCode, RefreshCw, ScanLine, Sparkles} from 'lucide-react';
import {
  Badge, Button, CheckMark, Chip, Cursor, Enter, HeroCard, Logo, Material, MaterialTag, Panel, Phone,
  Progress, QRMark, SearchField, Stage, Title, TravelingCard,
  box, cycle, line, mix, rectAt, tween, typed, useTime, type Rect,
} from './motion';

type Shot = {seconds:number;compact?:boolean};
export const tagSource:Rect=[1150,742,278,94];
export const tagTarget:Rect=[669,672,218,94];

export const Access = ({seconds,compact}:Shot) => {
  const t=useTime(seconds);
  const appear=tween(t,0,.16), morph=tween(t,.35,.69), panel=tween(t,.45,.69);
  const bounds=rectAt([605,428,710,166],[746,267,1066,580],morph);
  const focus=cycle(t,.23,.29,.34,.39);
  return <Stage area="Visão geral">
    <Title lines={compact?['Almox ERP']:['Gestão inteligente','de almoxarifado.']} t={t} size={compact?91:76} style={{top:compact?183:202}}/>
    <div className="v5-access-frame" style={{...box(bounds),opacity:appear,borderRadius:mix(25,31,morph),translate:`0 ${(1-appear)*27}px`,background:panel>.52?'#241e25':'#fff'}}>
      <div className="v5-access-prompt" style={{opacity:1-panel}}>
        <Logo width={82}/><div><b>Almox ERP</b><small>Acesso ao aplicativo</small></div>
        <Button pressed={focus} quiet={t>.30}>{t>.30?'Abrindo…':'Abrir painel'} <ArrowRight size={21}/></Button>
      </div>
      {panel>.01&&<div style={{position:'absolute',inset:0,opacity:panel}}><Panel title="Seu almoxarifado, hoje" subtitle="Materiais e operações da unidade" style={{height:'100%',borderRadius:0}}>
        <div className="v5-access-grid">
          {[[Boxes,'Produtos','24'],[MapPin,'Localizações','8'],[Bell,'Pendências','3']].map(([Icon,label,value],i)=>{
            const Symbol=Icon as typeof Boxes;
            return <Enter key={String(label)} t={t} start={.56+i*.045} move={18}>
              <div className="v5-dash-tile"><Symbol size={26}/><span>{String(label)}</span><b>{String(value)}</b></div>
            </Enter>;
          })}
        </div>
        <Enter t={t} start={.68} move={24} style={{height:77,marginTop:29}}>
          <SearchField text="" focus={tween(t,.78,.94)}/>
        </Enter>
      </Panel></div>}
    </div>
    <Cursor x={mix(1425,1198,tween(t,.11,.27))} y={mix(685,510,tween(t,.11,.27))} t={t} click={.29} show={cycle(t,.12,.19,.35,.45)}/>
  </Stage>;
};

export const SearchShot = ({seconds,compact}:Shot) => {
  const t=useTime(seconds), text=typed('Rolamento 6205',t,.13,.37);
  const expanded=tween(t,.50,.66), shrink=tween(t,.84,1);
  const start:Rect=[557,517,815,83], end:Rect=[642,514,625,192];
  const card=rectAt(start,end,expanded);
  const results=['Correia em V A42','Filtro hidráulico'];
  const localTag=tween(t,.73,.85);
  return <Stage area="Produtos">
    <Title lines={['Encontre o material.']} center t={t} detail="Localização e saldo disponível na mesma consulta."/>
    <Enter t={t} start={0} end={.09} style={box([552,387,824,87])}><SearchField text={text} focus={tween(t,.07,.13)} caret={t>.08&&t<.41&&Math.floor(t*28)%2===0}/></Enter>
    <Cursor x={mix(1422,680,tween(t,.01,.105))} y={mix(590,426,tween(t,.01,.105))} t={t} click={.103} show={cycle(t,.02,.07,.13,.28)}/>
    {results.map((name,i)=><Enter key={name} t={t} start={.31+i*.045} end={.44+i*.045} style={box([559,612+i*72,809,63])} move={25}>
      <div className="v5-row" style={{opacity:1-expanded,translate:`0 ${expanded*25}px`}}><span>{name}</span><small>{i===0?'MAT-081':'MAT-117'}</small></div>
    </Enter>)}
    <Enter t={t} start={.28} end={.43} style={box(card)} move={28}>
      <HeroCard style={{borderColor:expanded>.8?'#d1738a':undefined,padding:expanded>.3?22:15,borderRadius:mix(12,24,expanded)}}>
        <Material detail={expanded>.69}/>
      </HeroCard>
    </Enter>
    {t<.92&&<TravelingCard from={[724,618,255,67]} to={tagSource} arc={30} tilt={-8} p={localTag} style={{opacity:localTag}}><MaterialTag qr/></TravelingCard>}
    {!compact&&<div className="v5-guideline" style={{...box([567,811,447,2]),opacity:tween(t,.65,.82)*(1-shrink*.35)}}/>}
  </Stage>;
};

const BoxObject=({t}:{t:number})=>{
  const p=tween(t,0,.22);
  return <div style={{...box([564,544,425,269]),scale:.88+.12*p,translate:`0 ${(1-p)*52}px`}}>
    <svg width="425" height="316" viewBox="0 0 425 316" aria-hidden="true">
      <ellipse cx="228" cy="280" rx="198" ry="27" fill="#49362e" opacity=".10"/>
      <ellipse cx="224" cy="270" rx="161" ry="17" fill="#49362e" opacity=".11"/>
      <path d="M37 63 241 16 388 62 185 115Z" fill="#e1b986"/>
      <path d="M37 63 185 115 185 260 37 203Z" fill="#c49a6b"/>
      <path d="M185 115 388 62 388 205 185 260Z" fill="#b38656"/>
      <path d="M96 49 241 96 241 140 217 146 217 103 76 54Z" fill="#efd2a6" opacity=".82"/>
      <path d="M55 181 82 190M55 189 82 198" stroke="#916b4b" strokeWidth="3" opacity=".75"/>
      <path d="M345 195v-24m12 20v-24m-15 12 3-8 4 5m5 0 3-8 4 5" stroke="#755031" strokeWidth="2" fill="none"/>
    </svg>
  </div>;
};

const phoneQR:Rect=[1075,307,306,583];
const qrDock:Rect[]=[[1100,461,256,58],[1100,528,256,58],[1100,595,256,58]];
const qrOpen:Rect[]=[[650,356,311,87],[1432,557,330,88],[1442,360,271,86]];
const qrParts=[
  {icon:MapPin,title:'Localização',value:'Corredor A · Prateleira 03'},
  {icon:Package,title:'Rolamento 6205',value:'16 unidades disponíveis'},
  {icon:QrCode,title:'QR Code',value:'Etiqueta demonstrativa'},
];

export const QrShot = ({seconds}:Shot) => {
  const t=useTime(seconds);
  const entry=tween(t,.015,.19), scan=cycle(t,.20,.23,.39,.46), found=tween(t,.39,.47);
  return <Stage area="Leitor de QR Code">
    <Title lines={['Escaneie.','Localize.']} t={t} style={{top:206}}/>
    <BoxObject t={t}/>
    {t>.075&&<MaterialTag qr style={box(tagTarget)}/>}
    <Phone title="Leitor de QR Code" style={{...box(phoneQR),translate:`0 ${(1-entry)*155}px`,rotate:`${-7*(1-entry)}deg`}}>
      <div className="v5-viewfinder" style={{opacity:1-found}}>
        <QRMark size={165}/><span className="v5-scan-line" style={{top:`${line(t,.20,.43)*100}%`,opacity:scan}}/>
      </div>
      <div className="v5-phone-state" style={{opacity:found}}><Check size={17}/> Etiqueta identificada</div>
    </Phone>
    {qrParts.map(({icon:Icon,title,value},i)=>{
      const p=cycle(t,.45+i*.035,.59+i*.035,.75+i*.03,.92+i*.025);
      return <TravelingCard key={title} from={qrDock[i]} to={qrOpen[i]} p={p} arc={i===1?-15:27} tilt={(i-1)*8} style={{opacity:tween(t,.40+i*.023,.48+i*.025)}}>
        <div className="v5-docked" style={{fontSize:mix(14,20,p),borderRadius:mix(10,17,p),padding:mix(8,15,p),boxShadow:`0 ${p*13}px ${2+p*12}px #2e152722`}}>
          <Icon size={mix(17,28,p)}/><div><b>{title}</b><small style={{fontSize:mix(12,16,p)}}>{value}</small></div>
        </div>
      </TravelingCard>;
    })}
  </Stage>;
};

export const AssistantShot = ({seconds,compact}:Shot) => {
  const t=useTime(seconds), p=tween(t,.08,.27), reply=tween(t,.49,.60);
  const exploded=cycle(t,.61,.73,.83,.98);
  const query=typed('Onde está o Rolamento 6205?',t,.24,.47);
  const win=rectAt([1154,501,100,100],[696,294,1041,534],p);
  return <Stage area="Assistente do Almox" palette="ink">
    <Title lines={['Pergunte','ao Almox.']} t={t} detail="Localização e estoque em uma resposta." style={{top:329}}/>
    <div style={{...box(win),borderRadius:mix(22,30,p),overflow:'hidden',background:'#5b233e'}}>
      <div style={{...box([0,0,100,100]),display:'grid',placeItems:'center',opacity:1-p}}><Sparkles size={53} color="#ffe5f0"/></div>
      <div style={{position:'absolute',inset:0,opacity:p}}>
        <Panel title="Assistente do Almox" subtitle="Consulta de materiais" style={{height:'100%',borderRadius:0}}>
          <div className="v5-chat" style={{opacity:tween(t,.28,.39)}}>
            <div className="v5-chat-user">{query}{t<.47&&<i/>}</div>
            {t>=.49&&t<.60&&<div className="v5-dots">{[0,1,2].map(i=><i key={i} style={{opacity:.4+.55*(.5+.5*Math.sin(t*85-i))}}/>)}</div>}
            <div className="v5-chat-response" style={{opacity:reply}}><Sparkles size={22}/> Encontrei o rolamento no corredor A.</div>
          </div>
          <div className="v5-input"><span>{t<.48?query||'Digite sua pergunta':'Digite sua pergunta'}</span><Button pressed={cycle(t,.46,.48,.49,.53)}><ArrowUp size={22}/></Button></div>
        </Panel>
      </div>
    </div>
    <Cursor x={mix(1766,1663,tween(t,.40,.48))} y={mix(837,768,tween(t,.40,.48))} t={t} click={.48} show={cycle(t,.40,.45,.5,.57)}/>
    <TravelingCard from={[736,602,456,85]} to={compact?[1002,536,574,145]:[610,693,635,151]} p={exploded} arc={40} tilt={-6} style={{opacity:reply}}>
      <HeroCard style={{padding:mix(11,21,exploded)}}><Material detail={exploded>.7}/></HeroCard>
    </TravelingCard>
  </Stage>;
};

const receiptDesk:Rect=[235,570,688,99], receiptPhone:Rect=[1357,503,283,85];
export const DeliveryShot = ({seconds,compact}:Shot) => {
  const t=useTime(seconds), entered=tween(t,.025,.18);
  const toPhone=tween(t,.25,.49), toDesk=tween(t,.76,.91);
  const click=.62, refresh=.91, confirmed=t>=click, desktopDone=t>=refresh;
  const transfer=(toPhone>0&&toPhone<1)||(toDesk>0&&toDesk<1);
  const active=tween(t,.17,.25);
  const p=toPhone*(1-toDesk);
  const origin=rectAt(receiptDesk,[receiptDesk[0],receiptDesk[1]+(1-entered)*56,receiptDesk[2],receiptDesk[3]],1-tween(t,.10,.22));
  return <Stage palette="ink" area="Entregas e recebimentos">
    <Title lines={[compact?'Da entrega à confirmação.':'Rastreie cada entrega.']} t={t} detail="Registro no almoxarifado, conferência pelo destinatário."/>
    <svg style={box([530,488,965,200])} viewBox="0 0 965 200" aria-hidden="true">
      <path d="M5 117 C282 117 401 10 956 51" pathLength="1" fill="none" stroke="#db5f88" strokeWidth="3" opacity={transfer?.7:.18} strokeDasharray="6 10"/>
    </svg>
    <Enter t={t} start={0} end={.18} style={box([202,386,790,457])} move={56}>
      <Panel title="Recebimentos de materiais" subtitle="Acompanhar unidade" style={{height:'100%'}}>
        <div className="v5-receiptline"/><div className="v5-desktop-status">
          <Badge tone={desktopDone?'green':'amber'}>{desktopDone?'Recebimento confirmado':'Aguardando confirmação'}</Badge>
          <Button quiet pressed={cycle(t,.88,.91,.92,.97)}><RefreshCw size={18} style={{rotate:`${tween(t,.9,.98)*360}deg`}}/> Atualizar</Button>
        </div>
      </Panel>
    </Enter>
    <Phone title="Recebimentos" style={{...box([1327,331,343,559]),translate:`0 ${(1-entered)*235}px`,rotate:`${(1-entered)*8}deg`}}>
      <div className="v5-for-me">Para mim</div>
      <div className="v5-receipt-action" style={{opacity:tween(t,.45,.54)}}>
        <Button pressed={cycle(t,.59,click,.64,.69)} quiet={confirmed}>
          {confirmed?<><CheckMark p={tween(t,click,.70)} size={24}/> Confirmado</>:'Confirmar recebimento'}
        </Button>
      </div>
      <p className="v5-receipt-hint" style={{opacity:tween(t,.69,.76)}}>Registro do destinatário</p>
    </Phone>
    <TravelingCard from={origin} to={receiptPhone} p={p} arc={69} tilt={9} style={{opacity:active}}>
      <div className="v5-order" style={{borderRadius:mix(16,11,p),padding:mix(19,12,p),borderColor:confirmed?'#83cda4':undefined}}>
        <Package size={mix(29,22,p)}/><div><b style={{fontSize:mix(25,19,p)}}>Rolamento 6205</b><small>{p>.75?'4 unidades':'OS-DEMO-024 · 4 unidades · A-03-02'}</small></div>
        {confirmed&&<CheckMark p={tween(t,click,.70)} size={24}/>}
      </div>
    </TravelingCard>
    <Cursor x={mix(1735,1492,tween(t,.52,.61))} y={mix(736,638,tween(t,.52,.61))} t={t} click={click} show={cycle(t,.51,.56,.65,.7)}/>
    <Cursor x={mix(1060,881,tween(t,.81,.91))} y={mix(810,730,tween(t,.81,.91))} t={t} click={refresh} show={cycle(t,.81,.85,.94,.99)}/>
    <div style={{...box([225,888,740,6]),opacity:entered}}><Progress p={line(t,.20,.92)}/></div>
  </Stage>;
};
