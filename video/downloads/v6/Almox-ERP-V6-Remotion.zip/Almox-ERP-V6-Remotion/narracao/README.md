# Narração V6

Os horários de cues.json são janelas editoriais. A terceira versão depende de locução disponível em português brasileiro e escutada para conferir Almox, ERP, CSV e QR. O roteiro foi alinhado aos fluxos capturados de QR e assistente.

## Importação local

Coloque `01.wav` a `12.wav` (ou MP3 com os mesmos nomes) em `public/assets/audio/narration/`. Para uma faixa única `full.wav` ou `full.mp3`, inclua `alinhamento.json` com uma lista de objetos `{"scene": 1, "in": 0.16, "out": 3.2}`, medidos a partir da fala audível de cada tomada. Os valores desse exemplo são ilustrativos.

Após ouvir e validar frases, pronúncia e licença da voz, registre `{"provider":"ElevenLabs","reviewed":true}` em `origem.json` na mesma pasta. Execute `node scripts/validate-narration.mjs`. Se a voz couber e Full V6 já estiver disponível, execute `node scripts/validate-narration.mjs --master`. O processo mede durações, decodifica os trechos, aplica ducking e gera uma mixagem, um SRT e uma cópia do vídeo com a nova faixa.

Confira os dois canais e os 78 s. Ouça a voz no arquivo final e confirme a meta de −14 a −16 LUFS e true peak ≤ −1 dBTP com `ffmpeg -i out/final/Almox-ERP-Narrated-V6.mp4 -vn -af ebur128=peak=true -f null -`.

## Geração opcional

`node scripts/generate-narration.mjs` lista caracteres e cache local sem consultar a API. Use `--scene=N` para fazer uma tomada por vez. O modo `--preflight` confirma modelo, voz, plano, disponibilidade e estimativa a partir da API com variáveis locais. Use `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID` e, se necessário, `ELEVENLABS_MODEL_ID`. Defina segredos somente no ambiente ou em `.env.local`.

Uma geração autorizada usa `--generate --confirm-licensed-use --max-credits=N`. Estimativa e saldo devem caber no limite. O gerador preserva arquivos importados e reaproveita o cache para o mesmo texto, voz e configuração. Antes de exportar, revise a licença do plano e os termos da voz. [Documentação ElevenLabs](https://elevenlabs.io/docs/overview)
