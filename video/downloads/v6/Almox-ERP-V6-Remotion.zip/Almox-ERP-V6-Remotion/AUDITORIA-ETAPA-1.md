# Almox ERP V6 · Auditoria da etapa 1

A fonte do produto é o [Almox ERP 2.15.0 no commit 87ea41b](https://github.com/pedrowenz-a17y/almox/tree/87ea41bca37b338289da8209498492209d0fc4e5). O SHA completo, confirmado com `git rev-parse HEAD` e com a referência remota de `main`, é `87ea41bca37b338289da8209498492209d0fc4e5`. O projeto audiovisual preexistente fica em `/workspace/work/almox-v5`; sua branch local está em `/workspace/work/almox-v5-repo`. A etapa 1 usa uma cópia de trabalho Remotion com as composições anteriores preservadas.

Li o prompt, o guia e o inventário de referências deste pacote. Os dois MP4 V5 foram reproduzidos até o fim em Chromium local a 6× e inspecionados por quadros e pelas folhas de contato. Full e Launch têm 1920 × 1080, com duração de contêiner de 78,016 s e 35,008 s. O histórico `Almox-ERP (3).mp4` foi consultado como contexto. O `passo-main.mp4` de 13,4 s da V5 fica disponível como referência de movimento, em `/workspace/work/v5-kit/Almox-ERP-V5/`. O HTML e o material da etapa 2 não vieram nesta parte.

## Problemas observados e tratamento

| Full V5 | Launch V5 | Observação | Base da V6 |
| --- | --- | --- | --- |
| 00:01–00:04 | 00:01–00:02 | CTA ilustrativo “Abrir painel” e expansão para painel refeito. | Entrada editorial separada, seguida do dashboard real. |
| 00:07–00:10 | 00:04–00:07 | Campo com texto diferente e card mostra localização junto do resultado. | Consulta rápida com placeholder real, filtros por digitação e ficha posterior com saldo por local. |
| 00:14–00:18 | 00:08–00:11 | Cards de scanner misturam etiqueta, resultado e inventário, com camadas cruzando a moldura. | Scanner real com câmera fechada, localização por código fictício e etiqueta real da fixture na ficha. |
| 00:23–00:27 | 00:12–00:15 | Resposta do material desenhada à mão em painel ilustrativo. Card encobre parte da interface ao sair. | Painel original e protocolo de orientação por QR executado pelo serviço local. |
| 00:30–00:34 | — | Barras de progresso dão aparência de indicador nativo na reposição. | Linha real com disponível, mínimo, quantidade em compra e meta. |
| 00:36–00:40 | 00:16–00:19 | Três cartões editoriais simulam a UI. Os números sobem mesmo sem uma ação registrada. | Contagem de 24 esperadas, 23 contadas, diferença de −1. Bloqueio do autor, revisão por outra conta e estado após ação. |
| 00:40–00:41 | 00:29–00:32 | A troca por uma tela vermelha domina momentaneamente o quadro. | Cortes diretos nas bases. A cartela editorial do Launch tem texto contínuo em vez de um quadro vazio. |
| 00:43–00:47 | 00:21–00:25 | O trajeto do card e o rótulo “Confirmado” encurtam a distinção entre operador, conferência do destinatário e atualização. | Estados reais capturados separadamente, com diálogo de conferência e confirmação pela conta destinatária. |
| 00:50–00:53 | — | Movimentar um cartão parece trocar o titular. | Mostra “Aguardando aceite”, a ação “Aceitar e assumir turno” e o novo titular após aceite. |
| 00:55–00:60 | — | Arquivo vira tabela e revela diferenças sem explicitar pareamento e revisão autorizada. | Importação, prévia e parecer independente capturados com fixture de conciliação. |
| 01:02–01:06 | 00:25–00:29 | Cartões ilustrativos, alerta em primeiro plano sobre os demais. | Filtros e histórico reais. Leitura preserva o vínculo da pendência. |
| 01:08–01:12 | 00:25–00:29 | Indicadores genéricos e contagens sem origem na interface do gerencial. | Matriz e comparação autorizada da fixture oficial. |
| 01:14–01:18 | 00:32–00:35 | Telefone ilustrativo ao lado de painel miniaturizado. | Notebook/desktop e celular compostos a partir de capturas reais. A assinatura permanece estável. |

## Verificação do produto

A rota autenticada persistente do Next.js monta `ERP` no layout e troca as vistas com o caminho atual. Foram inspecionados `README.md`, `package.json`, `AGENTS.md`, `scripts/verify-theme.mjs`, `src/app/(workspace)/[[...slug]]/page.tsx`, `src/components/erp.tsx`, `src/lib/workspace-navigation.ts`, o CSS e os componentes e fixtures das telas selecionadas. Foram cruzadas as regras de Recebimentos 2.14, Turnos 2.9, Conciliação 2.11, Alertas 2.13 e Gerencial 2.15 com o código e os READMEs dos artefatos. Pasta de evidências versionada. [Capturas de QA do ERP](https://github.com/pedrowenz-a17y/almox/tree/87ea41bca37b338289da8209498492209d0fc4e5/artifacts)

O gerador de captura deriva do harness oficial e monta os componentes e o CSS do commit. O navegador se conecta ao servidor efêmero em loopback e bloqueia outras origens. Os GETs de dados e as operações de teste são respondidos por fixtures em memória. A orientação do assistente foi executada pelo serviço local com consulta da unidade desligada. A geração de Prisma Client foi usada para importar o serviço e não executou operações de banco. Os PNGs de versões antigas serviram à comparação. A composição V6 aponta para novas capturas da sessão isolada.

## Limites da etapa

A ação verificável de QR é a entrada manual e a navegação resultante. A leitura óptica exige o ensaio da etapa 2. Os componentes-base têm estados estáticos em sequência, recortes geométricos e cursor em controles medidos. A separação animada, máscaras de retorno, MotionLab, narração e os MP4 finais estão fora desta entrega.
