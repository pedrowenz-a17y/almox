# Almox ERP · Projeto Remotion

## V6 · Motion graphics

As composições da V6 ficam em `V6-Filmes` no Studio. Abra `AlmoxERP-MotionLab` para examinar recortes e movimentos. `AlmoxERP-MotionPrototype` reúne consulta, QR e recebimento. As tomadas editáveis de cada cena ficam em `Tomadas-V6`.

A imagem do ERP vem de `public/etapa1/manifest.json` e das capturas registradas no commit indicado. `src/v6/motion/Stage.tsx` concentra máscaras, cursor e conversão de coordenadas. `Heroes.tsx` e `Operations.tsx` têm a coreografia. `Film.tsx` reutiliza a duração e as cenas da etapa 1 e aplica os pontos de ação da montagem curta.

```sh
npm ci
npm run studio
npm run qa:v6
ALMOX_CHROMIUM=/usr/bin/chromium npm run render:v6:prototype
ALMOX_CHROMIUM=/usr/bin/chromium npm run render:v6:lab
ALMOX_CHROMIUM=/usr/bin/chromium npm run render:v6:full
ALMOX_CHROMIUM=/usr/bin/chromium npm run render:v6:launch
python scripts/contact-v6.py
```

O arquivo `QA-V6.md` registra a revisão e as limitações. `narracao/README.md` descreve a importação de voz ElevenLabs, o preflight de créditos e a masterização independente. A trilha instrumental pode ser recriada com NumPy e FFmpeg executando `python scripts/soundtrack-v6.py`.

## V6 · Etapa 1

Abra `V6-Etapa-1` no Studio para inspecionar as bases Full e Launch ou uma cena isolada. O ponto de partida para a próxima etapa é [HANDOFF-ETAPA-1.md](HANDOFF-ETAPA-1.md), com o caminho das capturas, a revisão de fidelidade e os comandos de verificação.

## Histórico V5

Filmes de produto em português brasileiro com animações por frame e dados demonstrativos. Os novos cortes reutilizam a marca, as fontes e o dashboard do projeto anterior.

| Composição | Quadros | Duração |
| --- | ---: | ---: |
| AlmoxERP-Full-V5 | 2340 | 78 s |
| AlmoxERP-Launch-V5 | 1050 | 35 s |
| AlmoxERP-Full-V5-Narrated | 2340 | 78 s |
| AlmoxERP-MotionPrototype-V5 | 390 | 13 s |

Use Node.js 22 ou superior, FFmpeg e FFprobe. Rode `npm ci`, `npm run studio` e escolha uma composição. O Remotion pode usar um Chromium instalado por meio da variável `ALMOX_CHROMIUM`.

```sh
npm run typecheck
npm run render:full
npm run render:launch
npm run render:prototype
npm run thumbnail
npm run validate
```

As cenas e os cortes ficam em `src/v5/`. As durações editoriais e os pontos de corte ficam em `src/v5/timeline.ts`. Os pontos de entrada e encaixe dos cards ficam ao lado das cenas que os usam. A trilha leva os efeitos em sincronia. Para recriá-la, instale NumPy e execute `python scripts/soundtrack.py`.

## Narração

O projeto contém o roteiro e o manifesto dos 12 clipes, com janela e quadros iniciais. A voz sugerida é Cajó, em português brasileiro. A geração na conta consultada exige créditos e está pendente. A prévia no Studio identifica essa condição.

- `npm run narration:plan` imprime as janelas e a contagem de caracteres localmente.
- Para usar áudio já disponível no ElevenLabs, exporte cada trecho em WAV e coloque-o no caminho indicado em `src/v5/narration.json`, sob `public/`.
- A geração por API é opcional. Se houver autorização explícita para créditos, configure as variáveis em `.env.local` a partir de `.env.example` e execute `npm run narration:generate -- --allow-credits`. Para um trecho, acrescente `--segment=03-qr`. O comando reutiliza o cache e preserva os WAVs existentes.
- `npm run render:narrated` mede os clipes, prepara a narração isolada e as legendas, faz o ducking da trilha durante as falas e renderiza o mesmo corte visual do Full com a nova mixagem.

A legenda segue os tempos realmente medidos. A validação requer os 12 clipes dentro das janelas e a revisão de pronúncia deve ser feita com a voz final. O render acessa os arquivos locais.
