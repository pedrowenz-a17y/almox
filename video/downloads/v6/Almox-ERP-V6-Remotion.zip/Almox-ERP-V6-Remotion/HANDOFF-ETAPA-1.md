# Almox ERP V6 · Handoff da etapa 1

O projeto Remotion está pronto para a etapa de motion design. As bases Full de 78 s e Launch de 35 s usam capturas dos componentes do Almox ERP 2.15.0, no commit `87ea41bca37b338289da8209498492209d0fc4e5` de `main`. Os dados e as contas são fictícios. A V5 continua disponível no mesmo projeto Remotion e na cópia anterior. [Código do ERP no commit verificado](https://github.com/pedrowenz-a17y/almox/tree/87ea41bca37b338289da8209498492209d0fc4e5)

## Materiais

| Caminho relativo ao projeto | Conteúdo |
| --- | --- |
| `AUDITORIA-ETAPA-1.md` | Erros observados nos dois cortes V5, timestamps, relação com o código oficial e correções. |
| `MAPA-DE-CENAS.md` | Storyboards, janelas, rotas, permissões e textos de interface. |
| `ASSET-MANIFEST.md` | Índice por cena com origem dos componentes, fixture, estado, tema e dimensão. |
| `public/etapa1/manifest.json` | 31 PNGs, seletores, estados, dimensões, DPR, scroll e retângulos em coordenadas CSS. |
| `public/etapa1/recortes/index.json` | 52 PNGs extraídos das capturas, com coordenadas CSS e pixels de origem. |
| `public/etapa1/checks*.json` | Relatórios de execução do navegador. |
| `src/v6/storyboard.ts` | Estados de tela por quadro e duração das duas montagens. |
| `src/v6/Assets.tsx`, `geometry.ts`, `Base.tsx` | Captura original, recorte, transformação para o palco, cursor medido e composição-base. |
| `src/Root.tsx` | Registro das duas bases e das 12 cenas Full separadas no grupo `V6-Etapa-1`. |
| `scripts/etapa1/` | Harness de captura, geração de recortes e verificação de geometria. |
| `out/etapa1/` | Sequências de PNG estático em 960 × 540, pranchas e lista dos quadros revisados. |

O projeto de trabalho fica em `/workspace/work/v6-etapa1`, a V5 em `/workspace/work/almox-v5` e a cópia de referência do ERP em `/workspace/work/almox-v6-reference`. A entrega local em `/workspace/output/Almox-ERP-V6-Etapa-1` inclui o ZIP Remotion com fontes, capturas e quadros estáticos. Os documentos também estão disponíveis avulsos nessa pasta. O `passo-main.mp4` disponível no histórico V5 fica em `/workspace/work/v5-kit/Almox-ERP-V5/passo-main.mp4`.

## Estado das cenas-base

| Cena | Evidência conferida nesta etapa |
| --- | --- |
| Abertura | Dashboard autenticado de teste, logo oficial e título externo. |
| Consulta rápida | Placeholder e botão originais, filtragem pelo código ROL-6204 e detalhe com saldo por localização. |
| QR | Scanner com câmera fechada, localização aberta pela entrada manual e QR da ficha apontando para o servidor efêmero de teste. |
| Assistente | Pergunta sobre QR e orientação gerada pelo motor local com a consulta da unidade desativada. |
| Reposição | Linha real com disponível, mínimo, em compra e meta. |
| Inventário | Bloqueio do autor, revisão da mesma contagem por outra conta autorizada e linha aprovada após a ação. |
| Entrega | Conferência do operador, espera, consentimento explícito no celular e recebimento confirmado pela conta destinatária. |
| Turno | Titular antes do aceite, diálogo na conta indicada e novo titular após aceite. |
| Conciliação | Mapeamento de colunas, linhas da prévia com diferença e conferência, parecer por outra pessoa autorizada. |
| Alertas | Filtros da Central e registro da leitura. |
| Gerencial | Comparação autorizada, indicadores com dados fictícios e captura móvel. |
| Encerramento | Logo oficial, dashboard e ficha de material. Último estado estável nas duas bases. |

O Launch tem uma montagem própria. Ele preserva os três estados de inventário e entrega. Reposição, Turno e CSV ficam no Full.

## Verificação executada

- A rodada principal registrou 72 verificações de navegador aprovadas. As rodadas focadas de CSV e Inventário registraram 17 e 6, respectivamente. Os relatórios contêm as verificações repetidas e as listas de erros de página e requisições inesperadas.
- O TypeScript passou. O verificador geométrico conferiu 46 estados das duas bases, 31 capturas e 9 posicionamentos de cursor. Incluiu duração, enquadramento, área segura, relação CSS/DPR e transformação inversa da ponta do cursor.
- Full e Launch abriram no Studio em Chromium, com a captura do painel carregada e sem erros de página.
- O ZIP foi testado após extração limpa. A instalação pelo lockfile, o TypeScript e a verificação de geometria passaram na cópia extraída.
- O verificador de MP4 histórico da V5 passou na pasta da V5, onde os dois vídeos originais estão disponíveis. Para a base V6, use o verificador de geometria. O ZIP da etapa contém os quadros PNG da V6.
- Foram conferidos 29 quadros Full e 19 Launch em 960 × 540. Os títulos e callouts ficam separados do produto. Nos quadros de contexto ou com dois dispositivos, textos auxiliares ficam menores. As capturas e recortes de alta resolução preservam esses detalhes para aproximações da próxima etapa.
- A cópia do ERP terminou com a árvore Git limpa. O harness usou APIs localmente simuladas, com o navegador restrito ao loopback. Nenhuma base de produção foi acessada.

## Comandos

Para abrir as bases, use Node.js 24 e as dependências fixadas no lockfile. A captura usou Chromium local, Playwright da árvore oficial, Prisma Client sem engine e Python com Pillow.

```sh
npm ci
npm run typecheck
node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON scripts/etapa1/validate.mjs
npm run studio -- --port=3006
```

No Studio, selecione `AlmoxERP-Full-V6-Base` ou `AlmoxERP-Launch-V6-Base`. Os comandos a seguir reproduzem as capturas. `erp_ref` deve apontar para uma cópia local de referência no SHA registrado. O gerador confere o commit e limpa a pasta temporária usada para adaptar o harness oficial. Prisma gera os módulos locais usados pelo motor do assistente, sem migração ou consulta de banco.

```sh
erp_ref=/workspace/work/almox-v6-reference
git -C "$erp_ref" rev-parse HEAD
(cd "$erp_ref" && npm ci --ignore-scripts --no-audit --no-fund && ./node_modules/.bin/prisma generate --no-engine)
node scripts/etapa1/capture.mjs "$erp_ref"
node scripts/etapa1/capture.mjs "$erp_ref" inventario
node scripts/etapa1/capture.mjs "$erp_ref" csv
python scripts/etapa1/crops.py
```

Os comandos abaixo produzem apenas PNGs nas posições da amostra revisada. Use um Chromium disponível e ajuste o caminho se necessário.

```sh
ALMOX_CHROMIUM=/usr/bin/chromium ./node_modules/.bin/remotion render \
  src/index.ts AlmoxERP-Full-V6-Base out/etapa1/full \
  --frames="$(sed -n '1p' out/etapa1/frames-list.txt)" --image-format=png --scale=0.5
ALMOX_CHROMIUM=/usr/bin/chromium ./node_modules/.bin/remotion render \
  src/index.ts AlmoxERP-Launch-V6-Base out/etapa1/launch \
  --frames="$(sed -n '2p' out/etapa1/frames-list.txt)" --image-format=png --scale=0.5
```

## Continuação

Os protótipos animados de todas as cenas estão pendentes. Use os retângulos medidos e os recortes para animar aproximações, saídas e retornos dos componentes. No QR, a leitura por câmera permanece por validar. O QR da captura é demonstrativo e seu servidor de destino já foi encerrado. As duas bases representam mudanças de estado em cortes por quadro.

MotionLab, estudo do HTML da etapa 2, coreografia de transições, narração e exportação final aguardam a execução da etapa 2. A etapa 1 gerou somente quadros PNG de verificação. Nenhuma geração externa, cobrança de créditos ou publicação foi realizada.
