import {execFileSync,spawnSync} from 'node:child_process';
import {existsSync,mkdirSync,readFileSync,statSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const {cues}=JSON.parse(readFileSync('narracao/cues.json','utf8'));
const folder=resolve('public/assets/audio/narration');
const output=resolve('out/audio');
const final=resolve('out/final');
const fullVideo=resolve(final,'Almox-ERP-Full-V6.mp4');
const bed=resolve('public/audio/v6-full.m4a');
const master=process.argv.includes('--master');
const duration=78;
const run=(bin,args)=>execFileSync(bin,args,{encoding:'utf8',maxBuffer:8*1024*1024});
const find=(stem)=>['wav','mp3'].map(ext=>resolve(folder,stem+'.'+ext)).find(existsSync);
const tm=(t)=>new Date(Math.round(t*1000)).toISOString().slice(11,23).replace('.',',');
const full=find('full');
const sourceManifest=resolve(folder,'origem.json');
if(!full&&!cues.some(c=>find(c.file_suggested.replace(/\.wav$/,'')))) {
  console.error('Locução ausente. Use full.wav/mp3 com alinhamento.json ou os clipes 01 a 12 na pasta de narração.');
  process.exit(2);
}
const provenance=existsSync(sourceManifest)?JSON.parse(readFileSync(sourceManifest,'utf8')):null;
if(provenance?.provider!=='ElevenLabs'||provenance?.reviewed!==true)
  throw Error('Registre origem ElevenLabs e a escuta de conteúdo e pronúncia em origem.json antes de aprovar a voz.');
function measure(path) {
  const raw=run('ffprobe',['-v','error','-select_streams','a:0','-show_entries','stream=duration','-of','json',path]);
  const seconds=Number(JSON.parse(raw).streams?.[0]?.duration);
  if(!Number.isFinite(seconds)||seconds<.65||!statSync(path).size)throw Error('Duração inválida ou trecho de teste: '+path);
  return seconds;
}
const timingPath=resolve(folder,'alinhamento.json');
if(full&&!existsSync(timingPath))throw Error('A faixa completa precisa de alinhamento.json com início e fim audíveis de cada fala.');
const alignment=full?JSON.parse(readFileSync(timingPath,'utf8')):null;
const fullLength=full?measure(full):0;
if(full&&fullLength>duration+.006)throw Error('A faixa ultrapassa 78 s. Ajuste o roteiro ou o tempo editorial sem cortar a fala.');
function detectSpeechWindow(path,inPoint,outPoint) {
  const result=spawnSync('ffmpeg',['-nostdin','-hide_banner','-v','info','-xerror','-ss',String(inPoint),'-i',path,
    '-t',String(outPoint-inPoint),'-map','0:a:0','-af','silencedetect=noise=-47dB:d=0.05,volumedetect','-f','null','-'],{encoding:'utf8'});
  if(result.error||result.status!==0)throw Error('Falha ao decodificar o arquivo '+path);
  const peak=Number(/max_volume:\s*(-?[0-9.]+) dB/.exec(result.stderr)?.[1]);
  if(!Number.isFinite(peak)||peak<-36)throw Error('O trecho de locução está vazio ou abaixo do nível útil: '+path);
  const silences=[...result.stderr.matchAll(/silence_start:\s*([0-9.e+-]+)\b|silence_end:\s*([0-9.e+-]+)\b/g)];
  const length=outPoint-inPoint;
  const leading=Number(silences[0]?.[1])<.04?Number(silences[1]?.[2]):0;
  const lastEnd=Number(silences.at(-1)?.[2]);
  const lastStart=Number(silences.at(-2)?.[1]);
  const trailing=Number.isFinite(lastStart)&&lastEnd>=length-.03?lastStart:length;
  return {in:inPoint+leading,out:inPoint+Math.min(trailing,length)};
}
const clips=cues.map(c=>{
  const path=full??find(c.file_suggested.replace(/\.wav$/,''));
  if(!path)throw Error('Arquivo ausente na cena '+c.scene);
  const inPoint=full?alignment.find(a=>a.scene===c.scene)?.in:0;
  const outPoint=full?alignment.find(a=>a.scene===c.scene)?.out:measure(path);
  if(!Number.isFinite(inPoint)||!Number.isFinite(outPoint)||inPoint<0||outPoint-inPoint<.65||full&&outPoint>fullLength)
    throw Error('Alinhamento inválido na cena '+c.scene);
  const detected=detectSpeechWindow(path,inPoint,outPoint);
  const trimIn=full?inPoint:Math.max(inPoint,detected.in-.045);
  const trimOut=full?outPoint:Math.min(outPoint,detected.out+.06);
  const start=full?inPoint:c.start_seconds_target+.16;
  const end=start+trimOut-trimIn;
  if(start<c.start_seconds_target||end>c.end_seconds_target+.006)
    throw Error(`A cena ${c.scene} termina em ${end.toFixed(2)} s, fora da janela ${c.start_seconds_target}–${c.end_seconds_target} s.`);
  return {scene:c.scene,path,start,end,trimIn,trimOut,subtitleStart:start+detected.in-trimIn,subtitleEnd:start+detected.out-trimIn,text:c.text};
});
console.table(clips.map(({scene,start,end})=>({scene,start,end})));
if(!master)process.exit(0);
if(!existsSync(fullVideo))throw Error('O Full V6 deve estar validado localmente antes da masterização narrada.');
mkdirSync(output,{recursive:true});
const stem=resolve(output,'Almox-ERP-Locucao-V6.wav');
const argumentsForClips=clips.flatMap(c=>['-i',c.path]);
const delays=clips.map((c,i)=>`[${i}:a]atrim=start=${c.trimIn}:end=${c.trimOut},asetpts=PTS-STARTPTS,highpass=f=78,aresample=48000,aformat=channel_layouts=stereo,adelay=${Math.round(c.start*48000)}S:all=1[a${i}]`);
const inputs=clips.map((_,i)=>`[a${i}]`).join('');
const isolated=delays.concat(`${inputs}amix=inputs=${clips.length}:normalize=0:dropout_transition=0,apad,atrim=duration=${duration}[stem]`).join(';');
const ffmpeg=(args)=>run('ffmpeg',['-nostdin','-hide_banner','-v','error','-xerror','-y',...args]);
ffmpeg([...argumentsForClips,'-filter_complex',isolated,'-map','[stem]','-c:a','pcm_s16le',stem]);
const mix=resolve(output,'Almox-ERP-Mix-Narrated-V6.m4a');
const duck='[0:a]volume=0.67[bed];[1:a]loudnorm=I=-18:TP=-2:LRA=8,aresample=48000,asplit=2[side][spoken];[bed][side]sidechaincompress=threshold=0.021:ratio=8:attack=24:release=280[down];[down][spoken]amix=inputs=2:normalize=0,loudnorm=I=-15.5:TP=-1.8:LRA=8[mix]';
ffmpeg(['-i',bed,'-i',stem,'-filter_complex',duck,'-map','[mix]','-ar','48000','-c:a','aac','-b:a','192k',mix]);
const exportPath=resolve(final,'Almox-ERP-Narrated-V6.mp4');
ffmpeg(['-i',fullVideo,'-i',mix,'-map','0:v:0','-map','1:a:0','-c','copy','-t','78','-movflags','+faststart',exportPath]);
writeFileSync(resolve(final,'Almox-ERP-Narrated-V6.pt-BR.srt'),clips.map((c,i)=>`${i+1}\n${tm(c.subtitleStart)} --> ${tm(c.subtitleEnd)}\n${c.text}\n`).join('\n'));
console.log('Master e SRT disponíveis para revisão de voz, sincronia e loudness.');
