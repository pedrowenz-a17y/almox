from pathlib import Path
from subprocess import Popen, PIPE
import json
import math
import sys

from PIL import Image, ImageDraw

CUTS = {
    "full": "out/final/Almox-ERP-Full-V6.mp4",
    "launch": "out/final/Almox-ERP-Launch-V6.mp4",
    "proto": "out/qa/Almox-ERP-MotionPrototype-V6.mp4",
    "lab": "out/qa/Almox-ERP-MotionLab-V6.mp4",
}
wc, hc = 320, 180
manifest = json.loads(Path("out/qa/manifest-cenas-v6.json").read_text())
qa = Path("out/qa/pranchas")
qa.mkdir(exist_ok=True, parents=True)

def compose(tiles, title, path):
    out = Image.new("RGB", (4 * wc, 30 + 201 * math.ceil(len(tiles) / 4)), "#151218")
    draw = ImageDraw.Draw(out)
    draw.text((10, 8), title, fill="#fff6f5")
    for i, (frame, tile) in enumerate(tiles):
        x, y = (i % 4) * wc, 30 + (i // 4) * 201
        out.paste(tile, (x, y))
        draw.text((x + 8, y + hc + 4), f"{frame / 30:06.2f}s / f{frame}", fill="#fff6f5")
    out.save(path, quality=89, optimize=True)

for key in sys.argv[1:] or CUTS:
    scenes = manifest["scenes"][key]
    frames = {frame for scene in scenes for frame in scene["sample"]}
    length = wc * hc * 3
    thumbs = {}
    with Popen([
        "ffmpeg", "-nostdin", "-v", "error", "-threads", "2", "-filter_threads", "1",
        "-i", CUTS[key], "-vf", f"scale={wc}:{hc}", "-an", "-fps_mode", "passthrough", "-pix_fmt", "rgb24",
        "-f", "rawvideo", "pipe:1",
    ], stdout=PIPE) as decode:
        for frame in range(scenes[-1]["end"]):
            data = decode.stdout.read(length)
            assert len(data) == length, (key, frame)
            if frame in frames:
                thumbs[frame] = Image.frombytes("RGB", (wc, hc), data)
        assert not decode.stdout.read(1), key
        assert decode.wait() == 0
    summary = []
    for i, scene in enumerate(scenes, 1):
        name = f"{i:02d}-{scene['id']}"
        sample = scene["sample"]
        compose([(frame, thumbs[frame]) for frame in sample], f"{key.upper()} · {scene['id']}", qa / f"{key}-{name}.jpg")
        chosen = [scene["start"], *scene["key"][1:6:2], scene["end"]-1]
        summary.extend((frame, thumbs[frame]) for frame in chosen)
    for i in range(0, len(summary), 20):
        compose(summary[i:i+20], f"{key.upper()} · etapas por cena", qa / f"{key}-resumo-{i//20+1:02d}.jpg")
    print(f"{key}: {len(frames)} quadros e {len(scenes)} pranchas por cena")
