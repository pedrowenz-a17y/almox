import assert from 'node:assert/strict';
import {execFileSync, spawnSync} from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const commit='87ea41bca37b338289da8209498492209d0fc4e5';
const source=path.resolve(process.argv[2]||'');
const output=fileURLToPath(new URL('../../public/etapa1/',import.meta.url));
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),commit);
const dir=await fs.mkdtemp(path.join(source,'scripts','.film-capture-'));
try {
  await fs.cp(path.join(source,'scripts/fixtures'),path.join(dir,'fixtures'),{recursive:true});
  for(const [name,needle,snip,before] of [
    ['delivery-receipts','await expect(dialog()).toContainText("A confirmação será feita depois");', 'await page.filmCapture("entrega-revisao", "[role=dialog]", "Operador revisa entrega para conta do ERP", {button:["Confirmar operação","button"]});'],
    ['delivery-receipts','await expect(dialog()).toContainText("10 UN");\n        await dialog().getByRole("checkbox").check();',`
      await expect(dialog().getByRole("checkbox")).toBeChecked();
      await expect(dialog().getByRole("button",{name:"Confirmar recebimento",exact:true})).toBeEnabled();
      await page.filmCapture("recebimento-com-aceite", "[role=dialog]", "Destinatário atestou conferência, antes do envio", {check:"[role=dialog] input[type=checkbox]",button:["Confirmar recebimento","button"]},390);
    `],
    ['delivery-receipts','await expect(dialog()).toContainText("10 UN");','await page.filmCapture("recebimento-consentimento", "[role=dialog]", "Destinatário confere quantidade e confirma", {button:["Confirmar recebimento","button"]}, 390);'],
    ['delivery-receipts','await expect(dialog()).toContainText("10 UN");',`
      await page.filmCapture("recebimento-sem-aceite", "[role=dialog]", "Destinatário antes de declarar a conferência integral", {check:"[role=dialog] input[type=checkbox]",button:["Confirmar recebimento","button"]},390);
    `],
    ['delivery-receipts','await expect(detail()).toContainText("Recebimento confirmado");','await page.filmCapture("recebimento-confirmado", ".receipt-detail", "Destinatário após aceite",{},390);'],
    ['delivery-receipts','await expect(detail()).toContainText("Aguardando confirmação");','await page.filmCapture("recebimento-aguardando", ".receipt-detail", "Consulta do operador, antes do aceite");'],
    ['erp-reconciliation','await expect(dialog().locator(".recon-lines tbody tr")).toHaveCount(2);','await page.filmCapture("csv-previa",".recon-lines","Prévia com linhas que conferem e divergências antes de registrar",{tabela:".recon-lines"});'],
    ['inventory-approval','await expect(approval()).toBeEnabled();',`
      // The film follows this record across both accounts. The upstream
      // checks still exercise their original records and roles.
      const reviewer = data.user;
      try {
        data.user = { ...reviewer, id: other.userId, name: other.user.name };
        await open(other.user.name);
        await expect(dialog().getByRole('status')).toContainText('Você registrou esta contagem');
        await expect(approval()).toBeDisabled();
        await page.filmCapture('inventario-autor', '[role=dialog]', 'Autor da mesma contagem impedido de autoaprovar');
      } finally {
        data.user = reviewer;
      }
      await open(other.user.name);
      await expect(approval()).toBeEnabled();`],
    ['inventory-approval',"await expect(page.locator('tbody tr').filter({ hasText: other.user.name })).toContainText('Aprovado');","await page.filmCapture('inventario-aprovado','tbody tr:has-text(\"Conferente de demonstração\")','Resultado Aprovado após ação do revisor');"],
    ['erp-reconciliation','await noOverflow(page);\n        await dialog().screenshot({\n          animations: "disabled",\n          path: path.join(output, "revisao-desktop-dark.png"),\n        });','await page.filmCapture("csv-revisao","[role=dialog]","Revisão independente e parecer antes da conclusão",{button:["Concluir com ressalvas","button"]});'],
    ['operational-responsibility',"await submitNote('Recebi as orientações e assumo o almoxarifado.', 'Aceitar e assumir turno');","await page.filmCapture('turno-aceitar','[role=dialog]','Aceite explícito pela pessoa indicada',{button:['Aceitar e assumir turno','button']});",true],
    ['operational-responsibility',"await expect(page.locator('.shift-current')).toContainText(incoming.name);","await page.filmCapture('turno-assumido','.shift-current','Novo titular após aceite');"],
    ['operational-alerts','await cards()\n          .first()\n          .getByRole("button", { name: "Marcar como lido", exact: true })',`
      await cards().first().evaluate(card=>card.scrollIntoView({block:"center",behavior:"instant"}));
      await page.filmCapture("alertas-pendentes",".alerts-cards > li","Alerta com ação de leitura e vínculo ao registro",{read:["Marcar como lido","button",0],first:".alerts-cards > li:nth-child(1)",second:".alerts-cards > li:nth-child(2)"});
    `,true],
    ['operational-alerts','await expect(cards().first()).toContainText("Lido por você");',`
      await page.filmCapture("alerta-lido",".alerts-cards > li","Alerta lido pela própria conta. A pendência continua",{first:".alerts-cards > li:nth-child(1)"});
    `],
  ]){
    const file=path.join(dir,'fixtures',name+'-checks.mjs');
    const code=await fs.readFile(file,'utf8');
    assert.ok(code.includes(needle),name+': '+needle);
    await fs.writeFile(file,code.replace(needle,before?snip+'\n        '+needle:needle+'\n        '+snip));
  }
  const upstream=await fs.readFile(path.join(source,'scripts/verify-theme.mjs'),'utf8');
  const marker="try {\n  if (!reconciliationOnly)";
  assert.ok(upstream.includes(marker));
  const prefix=upstream.split(marker)[0]
    .replace("from './qa-config.mjs'","from '../qa-config.mjs'")
    .replace("timezoneId: 'America/Sao_Paulo', serviceWorkers: 'block'","timezoneId: 'America/Sao_Paulo', deviceScaleFactor:2, reducedMotion:'reduce', serviceWorkers: 'block'")
    .replace("await context.route(fixtureURL + '/api/**'", "await context.route('**/*', route => new URL(route.request().url()).origin===fixtureURL ? route.continue() : route.abort());\nawait context.route(fixtureURL + '/api/**'");
  const scenario=await fs.readFile(new URL('./scenarios.mjs',import.meta.url),'utf8');
  const helper=`import {askLocalAssistant} from '@/services/local-assistant';
    const question='Como usar o QR Code?';
    const reply=await askLocalAssistant({id:'qa-user',unitId:'qa-unit',permissions:[]},{question,history:[],includeUnit:false});
    process.stdout.write(JSON.stringify({question,reply}));`;
  await fs.writeFile(path.join(dir,'assistant.mts'),helper);
  const entry=path.join(dir,'capture.mjs');
  await fs.writeFile(entry,prefix+"\nconst execFileSyncForAssistant=()=>JSON.parse(require('node:child_process').execFileSync('node',['--import','tsx',new URL('./assistant.mts',import.meta.url).pathname],{encoding:'utf8'}));\n"+scenario);
  const result=spawnSync(process.execPath,[entry,'--erp-reconciliation-only'],{cwd:source,stdio:'inherit',env:{
    PATH:process.env.PATH, TMPDIR:'/tmp', QA_ENVIRONMENT:'isolated',QA_BASE_URL:'http://127.0.0.1:9',
    QA_UNIT_ID:'123e4567-e89b-42d3-a456-000000000003', QA_ARTIFACT_DIR:output,
    ALMOX_CAPTURE_GROUP:process.argv[3]||'',
  }});
  if(result.error)throw result.error;
  process.exitCode=result.status??1;
} finally {
  await fs.rm(dir,{recursive:true,force:true});
}
