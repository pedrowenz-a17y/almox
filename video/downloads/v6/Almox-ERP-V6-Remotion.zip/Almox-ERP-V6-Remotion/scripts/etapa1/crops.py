import json
import math
from pathlib import Path

from PIL import Image

base = Path(__file__).resolve().parents[2] / "public" / "etapa1"
manifest = json.loads((base / "manifest.json").read_text(encoding="utf-8"))
folder = base / "recortes"
folder.mkdir(exist_ok=True)
crops = {}
for key, asset in manifest["assets"].items():
    with Image.open(base / asset["filename"]) as image:
        regions = {"alvo": asset["visible"]}
        regions.update({name: data["visible"] for name, data in asset["regions"].items() if data["visible"]})
        for name, region in regions.items():
            dpr = asset["dpr"]
            x = max(0, math.floor(region["x"] * dpr))
            y = max(0, math.floor(region["y"] * dpr))
            right = min(image.width, math.ceil((region["x"] + region["width"]) * dpr))
            bottom = min(image.height, math.ceil((region["y"] + region["height"]) * dpr))
            assert x < right and y < bottom, (key, name)
            filename = f"{key}--{name}.png"
            image.crop((x, y, right, bottom)).save(folder / filename)
            crops[f"{key}/{name}"] = {
                "file": "recortes/" + filename,
                "source": asset["filename"],
                "rectCssVisible": region,
                "rectPng": {"x": x, "y": y, "width": right - x, "height": bottom - y},
            }
(folder / "index.json").write_text(json.dumps(crops, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"{len(crops)} recortes PNG preparados.")
