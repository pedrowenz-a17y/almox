
const group=process.env.ALMOX_CAPTURE_GROUP;
const manifest={commit:'87ea41bca37b338289da8209498492209d0fc4e5',source:'https://github.com/pedrowenz-a17y/almox',fixtures:'Componentes do ERP no harness local com dados fictícios e requisições externas bloqueadas',assets:{}};
if(group)Object.assign(manifest.assets,JSON.parse(await fs.readFile(path.join(output,'manifest.json'),'utf8')).assets);
const originalScreenshot=page.screenshot.bind(page);
const resolveSelector=(selector)=>Array.isArray(selector)?page.getByRole(selector[1],{name:selector[0],exact:true}).nth(selector[2]??-1):page.locator(selector).first();
function intersection(rect,viewport){
  const x=Math.max(0,rect.x),y=Math.max(0,rect.y);
  return {x,y,width:Math.min(viewport.width,rect.x+rect.width)-x,height:Math.min(viewport.height,rect.y+rect.height)-y};
}
async function capture(key,selector,state,regions={},mobileWidth){
  const previous=page.viewportSize();
  if(mobileWidth) await page.setViewportSize({width:mobileWidth,height:844});
  try{
    const element=resolveSelector(selector);
    await element.waitFor({state:'visible',timeout:5500});
    await page.evaluate(()=>document.fonts.ready);
    if(regions.button) await resolveSelector(regions.button).scrollIntoViewIfNeeded();
    else await element.evaluate(el=>{
      const rect=el.getBoundingClientRect();
      if(rect.y<64||rect.y+Math.min(240,rect.height)>innerHeight)
        el.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
    });
    const metrics=await page.evaluate(()=>({dpr:devicePixelRatio,viewport:{width:innerWidth,height:innerHeight},scroll:{x:scrollX,y:scrollY},theme:document.documentElement.dataset.theme}));
    const bounds=await element.boundingBox();
    const visible=intersection(bounds,metrics.viewport);
    const regionsOfInterest={};
    for(const [id,value] of Object.entries(regions)){
      const target=resolveSelector(value);
      if(!(await target.count()))continue;
      const rect=await target.boundingBox();
      if(!rect)continue;
      const clipped=intersection(rect,metrics.viewport);
      regionsOfInterest[id]={selector:value,bounds:rect,visible:clipped.width>0&&clipped.height>0?clipped:null};
    }
    const filename=key+'.png';
    const bytes=await originalScreenshot({animations:'disabled',caret:'hide',path:path.join(output,filename)});
    manifest.assets[key]={filename,route:new URL(page.url()).pathname+new URL(page.url()).search,selector,state,bounds,visible,regions:regionsOfInterest,...metrics,png:{width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)}};
  } finally {
    if(mobileWidth)await page.setViewportSize(previous);
  }
}
page.filmCapture=capture;

const fixtureCaptures={
  'aprovacao-independente-desktop':['inventario-revisor','[role=dialog]','Revisor independente em Inventário'],
  'recebimentos-desktop-dark':['recebimentos-unidade','.receipt-cards','Consulta por unidade, com permissão'],
  'recebimentos-dark-390':['recebimentos-lista-mobile','.receipt-cards','Recebimentos em viewport de 390 px'],
  'passagem-turno-desktop':['turno-aguardando','.shift-handover','Titular anterior permanece até o aceite'],
  'importacao-desktop-dark':['csv-importar','.recon-import','Arquivo com colunas e critérios associados'],
  'alertas-desktop-dark':['alertas','.alerts-filters','Filtros da Central de alertas'],
  'leituras-desktop-dark':['alertas-leituras','.alerts-cards','Histórico de leituras da Central de alertas'],
  'gerencial-desktop-dark':['gerencial','.management-matrix','Visão da operação com unidades autorizadas'],
  'gerencial-mobile-light':['gerencial-mobile','.page-heading','Comparação de unidades no celular',{},390],
};
page.screenshot=async options=>{
  const entry=fixtureCaptures[path.basename(options.path||'','.png')];
  if(entry){await capture(...entry);return Buffer.alloc(0);}
  return originalScreenshot({...options,path:undefined});
};

const replenishment=data.products.slice(1,2).map(product=>({
  productId:product.id,code:product.internalCode,name:product.name,unit:product.unit,
  available:'7',minimum:'10',maximum:'20',incoming:'0',suggested:'13',
  supplierId:null,supplierName:'Sem fornecedor',locations:[],
}));
await page.route(fixtureURL+'/api/products/*/qr',async route=>{
  const id=new URL(route.request().url()).pathname.split('/')[3];
  if(!data.products.some(product=>product.id===id))return route.abort();
  const label=await QRCode.toString(fixtureURL+'/produto/'+id,{type:'svg',margin:4,errorCorrectionLevel:'M',color:{dark:'#202c31',light:'#ffffff'}});
  return route.fulfill({contentType:'image/svg+xml',body:label});
});
await page.route(fixtureURL+'/api/replenishment',route=>route.fulfill({json:{data:replenishment}}));

try{
  if(!group||group==='motion'){
  await check('Painel real',async()=>{
    await page.goto(fixtureURL+'/dashboard');
    await page.locator('.stats-grid').waitFor();
    await noOverflow(page);
    await capture('dashboard','.stats-grid','Painel autenticado com dados fictícios',{banner:'.scan-banner',stats:'.stats-grid'});
    if(group==='motion')await capture('dashboard-montagem','.stats-grid','Dashboard com três regiões de abertura',{left:'.stats-grid > :nth-child(1)',mid:'.stats-grid > :nth-child(2)',right:'.stats-grid > :nth-child(3)',banner:'.scan-banner'});
  });
  await check('Consulta rápida, digitação e detalhe',async()=>{
    await page.goto(fixtureURL+'/consulta');
    await expect(page.getByRole('heading',{name:'Consulta rápida'})).toBeVisible();
    const field=page.getByPlaceholder('Nome, código, SKU ou código de barras');
    await capture('consulta-inicial','.lookup-desk','Consulta rápida antes de digitar',{input:'#lookup-query',scan:['Escanear etiqueta','button']});
    await field.fill('ROL');
    await expect(page.locator('.lookup-material')).toHaveCount(1);
    await capture('consulta-digitando','.lookup-desk','Prefixo ROL filtra a lista',{input:'#lookup-query',resultado:'.lookup-material'});
    await field.fill('ROL-6204');
    await expect(page.locator('.lookup-material')).toHaveCount(1);
    await capture('consulta-resultado','.lookup-material','Resultado ROL-6204 com quantidade e estado',{input:'#lookup-query',resultado:'.lookup-material'});
    if(group==='motion')await capture('consulta-motion','.lookup-desk','Busca completa e resultado ROL-6204',{input:'#lookup-query',resultado:'.lookup-material'});
    await page.locator('.lookup-material').click();
    await expect(page.locator('.material-locations')).toContainText('Estante A');
    await capture('produto-localizacoes','.material-locations','Ficha real com saldo detalhado por localização',{locais:'.material-locations'});
  });
  await check('Scanner e etiqueta fictícia, com a câmera isolada',async()=>{
    await page.setViewportSize({width:390,height:844});
    try {
      await page.goto(fixtureURL+'/consulta');
      await page.getByRole('button',{name:'Escanear etiqueta',exact:true}).click();
      await capture('scanner-mobile','.scanner-card','Scanner inicial, câmera fechada',{manual:'.scanner-manual',camera:['Abrir câmera','button']});
      await page.route(fixtureURL+'/api/resolve?**',route=>{
        const location=data.locations[0];
        const code=new URL(route.request().url()).searchParams.get('code');
        return code===location.code?route.fulfill({json:{data:{...location,kind:'location'}}}):route.abort();
      });
      await page.getByLabel('Ou digite o código da localização').fill(data.locations[0].code);
      await page.getByRole('button',{name:'Localizar',exact:true}).click();
      await page.waitForURL('**/localizacao/'+data.locations[0].id);
      await capture('localizacao-manual','.page-heading','Localização aberta após consulta de código fictício');
      await page.goto(fixtureURL+'/produto/'+data.products[0].id);
      await page.locator('.product-qr-panel img').first().evaluate(img=>img.decode());
      await capture('etiqueta-mobile','.product-qr-panel','Etiqueta gerada para a fixture em localhost',{qr:'.product-qr-panel img'});
      await capture('produto-mobile','.material-locations','Ficha de material com distribuição por localização',{locais:'.material-locations'});
      if(group==='motion'){
        await capture('produto-qr-motion','.product-qr-panel','QR e código da mesma etiqueta na ficha móvel',{qr:'.product-qr-panel img',codigo:'.product-qr-panel .label-code'});
      }
      await noOverflow(page);
    } finally {await page.setViewportSize({width:1440,height:1000});}
  });
  await check('Assistente em modo local',async()=>{
    await page.goto(fixtureURL+'/dashboard'); await page.locator('.stats-grid').waitFor();
    await page.getByRole('button',{name:'Abrir assistente',exact:true}).click();
    await capture('assistente-local','.ai-panel','Modo local e composer reais',{composer:'.ai-composer'});
    if(!await fs.stat(path.join(root,'node_modules/.prisma/client')).catch(()=>null))throw new Error('Prisma Client não gerado para executar orientação local');
    const reply=execFileSyncForAssistant();
    await page.route(fixtureURL+'/api/assistant',async route=>{
      if(route.request().method()!=='POST')return route.fallback();
      const body=route.request().postDataJSON();
      if(body.question!==reply.question||body.includeUnit)return route.abort();
      return route.fulfill({json:{data:reply.reply}});
    });
    await page.locator('.ai-composer textarea').fill(reply.question);
    if(group==='motion')await capture('assistente-digitado','.ai-panel','Pergunta digitada antes de enviar',{text:'.ai-composer textarea',button:['Enviar pergunta','button']});
    await page.getByRole('button',{name:'Enviar pergunta',exact:true}).click();
    await expect(page.locator('.ai-assistant')).toContainText(reply.reply.answer.split('\n')[0].slice(0,55));
    await capture('assistente-resposta','.ai-panel','Orientação do motor local para QR, com consulta da unidade desativada',{reply:'.ai-assistant'});
    await page.unroute(fixtureURL+'/api/assistant');
  });
  await check('Reposição mostra a linha e critérios reais',async()=>{
    await page.goto(fixtureURL+'/reposicao');
    await expect(page.locator('tbody')).toContainText('COR-B72');
    await capture('reposicao','tbody tr','Linha de reposição, disponível 7 UN e mínimo 10 UN',{linha:'tbody tr'});
  });
  }
  if(!group||group==='inventario')await verifyInventoryApproval({page,fixtureURL,data,user,check,output,noOverflow});
  if(!group)await verifyDeliveryReceipts({page,fixtureURL,data,user,check,output,noOverflow,contrast});
  if(group==='motion')await verifyDeliveryReceipts({page,fixtureURL,data,user,check,output,noOverflow,contrast});
  if(!group)await verifyOperationalResponsibility({page,fixtureURL,data,user,check,output,noOverflow});
  if(!group||group==='csv')await verifyErpReconciliation({page,fixtureURL,data,user,check,output,noOverflow,contrast});
  if(!group)await verifyOperationalAlerts({page,fixtureURL,data,user,check,output,noOverflow,contrast});
  if(group==='motion'){
    await page.goto(fixtureURL+'/dashboard');
    await page.evaluate(()=>localStorage.setItem('almox-theme','dark'));
    await page.reload();
    await verifyOperationalAlerts({page,fixtureURL,data,user,check,output,noOverflow,contrast});
  }
  if(!group)await verifyManagement({page,fixtureURL,data,user,check,output,noOverflow,contrast});
} finally {
  await fs.writeFile(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  await fs.writeFile(path.join(output,group?'checks-'+group+'.json':'checks.json'),JSON.stringify({checks,errors,unexpected},null,2)+'\n');
  await browser.close();
  await new Promise(resolve=>server.close(resolve));
  await fs.rm(temporary,{recursive:true,force:true});
  process.exitCode=checks.some(c=>!c.passed)||errors.length||unexpected.length?1:0;
}
