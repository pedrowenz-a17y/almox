import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {centerOf,fitCapture,focusCrop,mapCapturePoint,screenSlots} from '../../src/v6/geometry.ts';
import {duration,full,launch} from '../../src/v6/storyboard.ts';
const assetDir=new URL('../../public/etapa1/',import.meta.url);
const manifest=JSON.parse(readFileSync(new URL('manifest.json',assetDir),'utf8'));
const stats={states:0,assets:0,cursors:0};
const contains=(outer,inner)=>inner.x>=outer.x-.1&&inner.y>=outer.y-.1&&inner.x+inner.width<=outer.x+outer.width+.1&&inner.y+inner.height<=outer.y+outer.height+.1;
assert.equal(duration(full),2340);
assert.equal(duration(launch),1050);
for(const [id,asset] of Object.entries(manifest.assets)){
  const bytes=readFileSync(new URL(asset.filename,assetDir));
  assert.equal(bytes.readUInt32BE(16),asset.viewport.width*asset.dpr,id);
  assert.equal(bytes.readUInt32BE(20),asset.viewport.height*asset.dpr,id);
  assert.ok(contains({x:0,y:0,...asset.viewport},asset.visible),id);
  for(const region of Object.values(asset.regions)){
    if(region.visible)assert.ok(contains({x:0,y:0,...asset.viewport},region.visible),id);
  }
  stats.assets++;
}
for(const scenes of [full,launch])for(const scene of scenes){
  assert.equal(scene.beats[0].frame,0,scene.id);
  for(const [i,beat] of scene.beats.entries()){
    assert.ok(beat.frame<scene.frames&&(i===0||beat.frame>scene.beats[i-1].frame),scene.id);
    assert.ok(beat.screens.length<=2,scene.id);
    for(const [index,selector] of beat.screens.entries()){
      const asset=manifest.assets[selector.asset];
      assert.ok(asset,selector.asset);
      const slot=screenSlots(beat.screens.length)[index];
      const viewport={x:0,y:0,...asset.viewport};
      const crop=selector.view==='focus'?focusCrop(asset.viewport,asset.visible):viewport;
      assert.ok(contains(viewport,crop)&&contains(crop,asset.visible),selector.asset);
      const fitted=fitCapture(crop,slot);
      assert.ok(contains(slot,fitted),selector.asset);
      assert.ok(fitted.x>=630&&fitted.x+fitted.width<=1832,selector.asset);
      if(selector.cursor){
        const region=asset.regions[selector.cursor]?.visible;
        assert.ok(region,selector.asset+' sem alvo de cursor visível');
        const expected=centerOf(region);
        const point=mapCapturePoint(expected,crop,slot);
        assert.ok(point,selector.asset+' alvo fora do recorte');
        assert.ok(contains({x:80,y:80,width:1760,height:920},{...point,width:36,height:45}),selector.asset+' cursor fora da área segura');
        assert.ok(Math.abs((point.x-fitted.x)/fitted.scale+crop.x-expected.x)<.01,selector.asset);
        assert.ok(Math.abs((point.y-fitted.y)/fitted.scale+crop.y-expected.y)<.01,selector.asset);
        stats.cursors++;
      }
    }
    stats.states++;
  }
}
console.log(JSON.stringify(stats));
