import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {existsSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {full,launch} from '../src/v6/storyboard.ts';
const base=JSON.parse(readFileSync('public/etapa1/manifest.json','utf8'));

const plans={
  Abertura:{key:[9,28,54,78,117],assets:['dashboard-montagem','dashboard'],tech:'Perspectiva, montagem reversa em três recortes, máscara, push-in e título escalonado'},
  Consulta:{key:[18,28,40,55,69,91,109,135],assets:['consulta-inicial','consulta-digitando','consulta-motion','produto-localizacoes'],tech:'Digitação em estados capturados, cursor por geometria, recorte que se expande e match cut para ficha'},
  QR:{key:[18,55,86,108,124,148,176,191,217,236],assets:['scanner-mobile','localizacao-manual','produto-qr-motion','produto-localizacoes'],tech:'Caixa CSS 3D, etiqueta fictícia, celular em perspectiva e dois recortes que retornam'},
  Assistente:{key:[24,52,75,121,139,163,189,249,279],assets:['assistente-local','assistente-digitado','assistente-resposta'],tech:'Digitação mascarada, cursor de envio e destaque da mensagem com retorno'},
  Reposicao:{key:[18,35,66,126,149],assets:['reposicao'],tech:'Máscara lateral, aproximação e retorno da linha de critérios reais'},
  Inventario:{key:[20,40,52,67,118,131,154],assets:['inventario-autor','inventario-revisor','inventario-aprovado'],tech:'Stagger e revelação de números editoriais medidos, estado de aprovação independente'},
  Entrega:{key:[20,54,61,88,105,114,127,148,155,176,197],assets:['entrega-revisao','recebimento-aguardando','recebimento-sem-aceite','recebimento-com-aceite','recebimento-confirmado'],tech:'Transferência editorial, cursor mapeado, formulário original e confirmação após ação'},
  Turno:{key:[16,48,63,101,112,117,146],assets:['turno-aguardando','turno-aceitar','turno-assumido'],tech:'Recorte em perspectiva, cursor no aceite e estado real do novo titular'},
  CSV:{key:[17,44,64,68,79,93,138,181],assets:['csv-importar','csv-previa','csv-revisao'],tech:'Documento editorial em perspectiva, montagem de linhas e zoom de parecer'},
  Alertas:{key:[14,30,57,94,108,126,153],assets:['alertas-pendentes','alerta-lido'],tech:'Empilhamento de alertas reais, cursor no botão de leitura, novo estado preserva pendência'},
  Gerencial:{key:[14,34,58,103,128,148,170],assets:['gerencial','gerencial-mobile'],tech:'Três colunas recompostas, comparação real, pullback e celular'},
  Assinatura:{key:[12,28,47,62,82],assets:[],tech:'Tipografia cinética em máscaras e transição para a mensagem institucional'},
  Encerramento:{key:[12,38,61,81,110,144],assets:['dashboard','produto-mobile'],tech:'Revelação da marca original e conjunto notebook e smartphone com repouso final'},
};
const lab=[['Abertura',120],['Consulta',120],['QR',150],['Inventario',114],['Entrega',144],['Gerencial',120],['Assinatura',90],['Encerramento',105]];
const proto=[['Consulta',132],['QR',144],['Entrega',144]];
const sections={full,launch,lab:lab.map(([id,frames])=>({id,frames})),proto:proto.map(([id,frames])=>({id,frames}))};
const outputs={
  full:['out/final/Almox-ERP-Full-V6.mp4',2340,1920,1080,true],
  launch:['out/final/Almox-ERP-Launch-V6.mp4',1050,1920,1080,true],
  proto:['out/qa/Almox-ERP-MotionPrototype-V6.mp4',420,960,540,false],
  lab:['out/qa/Almox-ERP-MotionLab-V6.mp4',963,960,540,false],
};
mkdirSync('out/qa',{recursive:true});
const entriesFor=(sections)=> {
  let start=0;
  return sections.map(({id,frames})=>{
    const plan=plans[id];
    assert(plan,id);
    const nominal=full.find(s=>s.id===id)?.frames??90;
    const key=plan.key.map(n=>start+Math.min(frames-1,Math.round(n/(nominal-1)*(frames-1))));
    const indices=new Set([start,start+frames-1,...key]);
    for(let i=0;i<frames;i+=30)indices.add(start+i);
    for(const event of key)for(const delta of [-15,-8,8,15])if(event+delta>=start&&event+delta<start+frames)indices.add(event+delta);
    const row={id,start,frames,end:start+frames,key,sample:[...indices].sort((a,b)=>a-b),tech:plan.tech,assets:plan.assets};
    plan.assets.forEach(id=>assert(base.assets[id],id));
    start+=frames;
    return row;
  });
};
const scenes=Object.fromEntries(Object.entries(sections).map(([key,sections])=>[key,entriesFor(sections)]));
writeFileSync('out/qa/manifest-cenas-v6.json',JSON.stringify({source:base.source,commit:base.commit,fixture:base.fixtures,fps:30,scenes},null,2)+'\n');
const file=process.argv[2];
const requested=file?[file]:Object.keys(outputs);
const proof={};
for(const name of requested){
  const [path,frames,width,height,audio]=outputs[name];
  assert.equal(scenes[name].at(-1).end,frames);
  if(!existsSync(path)){if(file)throw Error('Arquivo ausente: '+path);continue;}
  const data=JSON.parse(execFileSync('ffprobe',['-v','error','-show_streams','-show_format','-of','json',path],{encoding:'utf8'}));
  const v=data.streams.find(s=>s.codec_type==='video'),a=data.streams.find(s=>s.codec_type==='audio');
  assert.equal(v.codec_name,'h264',name);
  assert.ok(['yuv420p','yuvj420p'].includes(v.pix_fmt),name);
  assert.equal(v.width,width,name);
  assert.equal(v.height,height,name);
  assert.equal(v.avg_frame_rate,'30/1',name);
  assert.equal(Number(v.nb_frames),frames,name);
  assert.ok(Math.abs(Number(data.format.duration)-frames/30)<.047,name);
  assert.equal(Boolean(a),audio,name);
  if(audio){
    assert.equal(a.codec_name,'aac');
    assert.equal(a.channels,2);
    assert.ok(Math.abs(Number(a.duration)-frames/30)<.047);
  }
  proof[name]={path,width,height,frames,duration:+v.duration,fps:30,audio:a?{codec:a.codec_name,channels:a.channels,duration:+a.duration}:null};
}
console.log(JSON.stringify(proof,null,2));
