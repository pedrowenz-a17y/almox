from soundtrack import score

# Accents follow the decisions and confirmations in the two cuts.
score("v6-full", 78, [5, 11, 19, 29, 35, 41, 48, 54, 61, 67, 73], [
    (0.3, "logo"), (5.87, "click"), (8.03, "click"), (12.84, "click"),
    (23.63, "click"), (37.23, "click"), (39.4, "confirm"),
    (43.03, "click"), (45.23, "click"), (46.17, "click"),
    (46.35, "confirm"), (51.73, "click"), (51.9, "confirm"),
    (56.27, "click"), (64.6, "click"), (74.1, "logo"),
])
score("v6-launch", 35, [3, 7, 11, 15, 19, 25, 25+59/30, 29, 32], [
    (.32, "logo"), (3.35, "click"), (4.54, "click"), (8.06, "click"),
    (12.62, "click"), (17.64, "confirm"), (20.55, "click"),
    (22.27, "click"), (23.23, "click"), (23.5, "confirm"),
    (26.04, "click"), (32.5, "logo"),
])
