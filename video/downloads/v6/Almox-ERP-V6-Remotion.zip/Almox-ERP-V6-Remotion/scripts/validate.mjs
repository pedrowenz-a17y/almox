import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {existsSync} from 'node:fs';

const expected=[
  ['Almox-ERP-Full-V5.mp4',2340],
  ['Almox-ERP-Launch-V5.mp4',1050],
];
if(existsSync('out/final/Almox-ERP-Full-V5-Narrated.mp4'))expected.push(['Almox-ERP-Full-V5-Narrated.mp4',2340]);
for(const [name,frames] of expected){
  const {streams}=JSON.parse(execFileSync('ffprobe',['-v','error','-show_streams','-of','json','out/final/'+name],{encoding:'utf8'}));
  const v=streams.find(s=>s.codec_type==='video');
  const a=streams.find(s=>s.codec_type==='audio');
  assert.equal(v.width,1920,name);
  assert.equal(v.height,1080,name);
  assert.equal(v.avg_frame_rate,'30/1',name);
  assert.equal(v.codec_name,'h264',name);
  assert.equal(Number(v.nb_frames),frames,name);
  assert.equal(a?.codec_name,'aac',name);
  assert.equal(a?.channels,2,name);
  console.log(name+' · '+frames+' quadros · Full HD · 30 FPS · H.264/AAC estéreo');
}
