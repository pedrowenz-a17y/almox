import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {existsSync, mkdirSync, readFileSync, renameSync, writeFileSync} from 'node:fs';
import {dirname, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const manifestPath=resolve(root,'src/v5/narration.json');
const manifest=JSON.parse(readFileSync(manifestPath,'utf8'));
const [mode='plan',...args]=process.argv.slice(2);
const segmentOption=args.find(arg=>arg.startsWith('--segment='));
const requested=segmentOption?.slice('--segment='.length);
const chosen=requested?manifest.segments.filter(segment=>segment.id===requested):manifest.segments;
if(!chosen.length)throw Error('Segmento desconhecido.');
if(process.env.ELEVENLABS_API_KEY===undefined&&existsSync(resolve(root,'.env.local')))process.loadEnvFile(resolve(root,'.env.local'));

const voice=process.env.ELEVENLABS_VOICE_ID||manifest.suggestedVoiceId;
const model=process.env.ELEVENLABS_MODEL_ID||manifest.model;
const settings={stability:.63,similarity_boost:.75,use_speaker_boost:true};
const paragraph=text=>text.replace(/\bERP\b/g,'ê erre pê').replace(/\bQR\b/g,'quê erre').replace(/\bCSV\b/g,'cê ésse vê');
const audioPath = segment => resolve(root,'public',segment.path);
const cacheKey=segment=>createHash('sha256').update(JSON.stringify([paragraph(segment.text),voice,model,settings])).digest('hex');
const execute=(bin,argv)=>execFileSync(bin,argv,{encoding:'utf8',maxBuffer:4*1024*1024});
const ffmpeg=(argv)=>execute('ffmpeg',['-nostdin','-v','error','-y',...argv]);
const timecode=(frame)=>{
  const milliseconds=Math.round(frame*1000/manifest.fps);
  return new Date(milliseconds).toISOString().slice(11,23).replace('.',',');
};

if(mode==='plan'){
  console.table(chosen.map(segment=>({segmento:segment.id,caracteres:paragraph(segment.text).length,janela:segment.maxEnd-segment.start,cache:existsSync(audioPath(segment))?'local':cacheKey(segment).slice(0,12)})));
  console.log('Modelo:',model,'· caracteres:',chosen.reduce((n,segment)=>n+paragraph(segment.text).length,0));
}else if(mode==='generate'){
  if(!args.includes('--allow-credits'))throw Error('A geração ElevenLabs exige autorização para créditos e --allow-credits.');
  const key=process.env.ELEVENLABS_API_KEY;
  if(!key)throw Error('Configure ELEVENLABS_API_KEY no ambiente ou em .env.local.');
  for(const segment of chosen){
    const path=audioPath(segment);
    if(existsSync(path)){console.log('Arquivo local preservado:',segment.id);continue;}
    const hash=cacheKey(segment);
    const cache=resolve(root,'out/audio/cache',hash+'.mp3');
    mkdirSync(dirname(cache),{recursive:true});
    mkdirSync(dirname(path),{recursive:true});
    if(!existsSync(cache)){
      const current=manifest.segments.indexOf(segment);
      const response=await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`,{
        method:'POST',
        headers:{'xi-api-key':key,'content-type':'application/json',accept:'audio/mpeg'},
        body:JSON.stringify({text:paragraph(segment.text),model_id:model,voice_settings:settings,
          previous_text:current>0?paragraph(manifest.segments[current-1].text):undefined,
          next_text:current+1<manifest.segments.length?paragraph(manifest.segments[current+1].text):undefined}),
        signal:AbortSignal.timeout(90000),
      });
      if(!response.ok)throw Error(`O ElevenLabs retornou HTTP ${response.status} em ${segment.id}.`);
      const temp=cache+'.partial';
      writeFileSync(temp,Buffer.from(await response.arrayBuffer()));
      renameSync(temp,cache);
    }
    const temp=path+'.partial.wav';
    ffmpeg(['-i',cache,'-af','silenceremove=start_periods=1:start_duration=0.025:start_threshold=-48dB','-ar','48000','-ac','1','-c:a','pcm_s16le',temp]);
    renameSync(temp,path);
    console.log('Locução preparada:',segment.id);
  }
}else if(mode==='validate'){
  const missing=manifest.segments.filter(segment=>!existsSync(audioPath(segment)));
  if(missing.length)throw Error('Clipes ausentes: '+missing.map(segment=>segment.id).join(', '));
  const validated=manifest.segments.map(segment=>{
    const value=execute('ffprobe',['-v','error','-select_streams','a:0','-show_entries','stream=duration','-of','json',audioPath(segment)]);
    const duration=Number(JSON.parse(value).streams?.[0]?.duration);
    if(!Number.isFinite(duration)||duration<=0)throw Error(`Duração inválida de ${segment.id}.`);
    const durationFrames=Math.ceil(duration*manifest.fps);
    if((segment.startFrame+durationFrames)/manifest.fps>segment.maxEnd){
      throw Error(`${segment.id} tem ${duration.toFixed(2)} s e passa do limite de ${segment.maxEnd} s. Regrave ou ajuste o clipe sem cortar palavras.`);
    }
    return {...segment,duration,durationFrames,status:'validated'};
  });
  const audioDir=resolve(root,'out/audio');
  const finalDir=resolve(root,'out/final');
  mkdirSync(audioDir,{recursive:true});
  mkdirSync(finalDir,{recursive:true});
  const isolated=resolve(audioDir,'Almox-ERP-Narration-PT-BR.wav');
  const bed=resolve(root,'public/audio/v5-full.m4a');
  const mix=resolve(root,'public/audio/v5-narrated.m4a');
  const argumentsForClips=validated.flatMap(s=>['-i',audioPath(s)]);
  const delays=validated.map((s,i)=>`[${i}:a]highpass=f=72,aresample=48000,aformat=channel_layouts=stereo,adelay=${Math.round(s.startFrame*1600)}S:all=1[a${i}]`);
  const stemInputs=validated.map((_,i)=>`[a${i}]`).join('');
  const isolatedFilter=delays.concat(`${stemInputs}amix=inputs=${validated.length}:normalize=0:dropout_transition=0,apad,atrim=duration=78[stem]`).join(';');
  ffmpeg([...argumentsForClips,'-filter_complex',isolatedFilter,'-map','[stem]','-c:a','pcm_s16le',isolated]);
  const attenuation=validated.map(s=>{
    const start=s.startFrame/manifest.fps, end=start+s.duration;
    return `if(between(t,${start-.12},${end+.2}),min(1,max(0,(t-${start-.12})/.12))*min(1,max(0,(${end+.2}-t)/.2)),0)`;
  });
  const duck=attenuation.reduce((a,b)=>`max(${a},${b})`);
  const mixFilter=`[0:a]volume='0.76-0.49*(${duck})':eval=frame[bed];[1:a]acompressor=threshold=0.15:ratio=2:attack=9:release=100[voice];[bed][voice]amix=inputs=2:normalize=0,loudnorm=I=-15.5:TP=-1.5:LRA=8[mixed]`;
  ffmpeg(['-i',bed,'-i',isolated,'-filter_complex',mixFilter,'-map','[mixed]','-ar','48000','-c:a','aac','-b:a','192k','-t','78',mix]);
  const captions=validated.map((s,i)=>`${i+1}\n${timecode(s.startFrame)} --> ${timecode(s.startFrame+s.durationFrames)}\n${s.text}\n`).join('\n');
  writeFileSync(resolve(finalDir,'Almox-ERP-Full-V5-Narrated.pt-BR.srt'),captions+'\n');
  writeFileSync(manifestPath,JSON.stringify({...manifest,segments:validated},null,2)+'\n');
  console.log('Os 12 clipes cabem nas janelas. Áudio e legendas preparados.');
}else{
  throw Error('Use plan, generate ou validate.');
}
