import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const cues=JSON.parse(readFileSync('narracao/cues.json','utf8')).cues;
const folder=resolve('public/assets/audio/narration');
const cacheDir=resolve('out/audio/elevenlabs-cache');
const args=process.argv.slice(2);
const option=(key)=>args.find(arg=>arg.startsWith(key+'='))?.slice(key.length+1);
const scene=option('--scene');
const selected=scene?cues.filter(c=>c.scene===Number(scene)):cues;
if(!selected.length)throw Error('Cena inválida. Selecione de 1 a 12.');
if(!process.env.ELEVENLABS_API_KEY&&existsSync('.env.local'))process.loadEnvFile('.env.local');
const voice=process.env.ELEVENLABS_VOICE_ID;
const model=process.env.ELEVENLABS_MODEL_ID||'eleven_multilingual_v2';
const voice_settings={stability:.60,similarity_boost:.75,use_speaker_boost:true};
const pronounce=(text)=>text.replace(/\bERP\b/g,'ê erre pê').replace(/\bQR\b/g,'quê erre').replace(/\bCSV\b/g,'cê ésse vê');
const describe=(cue)=>{
  const body={text:pronounce(cue.text),model_id:model,voice_settings,
    previous_text:cue.scene>1?pronounce(cues[cue.scene-2].text):undefined,
    next_text:cue.scene<cues.length?pronounce(cues[cue.scene].text):undefined};
  const hash=createHash('sha256').update(JSON.stringify({voice,body})).digest('hex');
  const stem=cue.file_suggested.replace(/\.wav$/,'');
  return {body,stem,scene:cue.scene,cache:resolve(cacheDir,hash+'.mp3'),
    local:['wav','mp3'].some(ext=>existsSync(resolve(folder,stem+'.'+ext)))};
};
const entries=selected.map(describe);
console.table(entries.map(e=>({cena:e.scene,caracteres:[...e.body.text].length,status:e.local?'importado':existsSync(e.cache)?'cache':'pendente'})));
if(!args.includes('--preflight')&&!args.includes('--generate'))process.exit(0);
if(!voice||!process.env.ELEVENLABS_API_KEY)throw Error('Configure ELEVENLABS_VOICE_ID e ELEVENLABS_API_KEY no ambiente antes do preflight da conta.');
const headers={'xi-api-key':process.env.ELEVENLABS_API_KEY};
const url='https://api.elevenlabs.io/v1';
async function get(path) {
  const response=await fetch(url+path,{headers,signal:AbortSignal.timeout(20000)});
  if(!response.ok)throw Error(`Preflight ${path} retornou HTTP ${response.status}.`);
  return response.json();
}
const [modelList,voiceData,subscription]=await Promise.all([get('/models'),get('/voices/'+encodeURIComponent(voice)),get('/user/subscription')]);
const mode=modelList.find(m=>m.model_id===model&&m.can_do_text_to_speech);
const multiplier=mode?.token_cost_factor;
if(typeof multiplier!=='number'||multiplier<=0)throw Error('A API não confirmou a taxa do modelo. A geração foi interrompida.');
const costs=entries.filter(e=>!e.local&&!existsSync(e.cache)).map(e=>Math.ceil([...e.body.text].length*multiplier));
const estimate=costs.reduce((total,cost)=>total+cost,0);
const quota=subscription.character_limit-subscription.character_count;
console.log(JSON.stringify({modelo:model,voz:voiceData.name,plano:subscription.tier,estimativa_creditos:estimate,quota_restante:quota}));
if(!args.includes('--generate'))process.exit(0);
const budget=Number(option('--max-credits'));
if(!args.includes('--confirm-licensed-use')||!Number.isInteger(budget)||budget<0||!Number.isFinite(quota)||estimate>budget||estimate>quota)
  throw Error('Use --confirm-licensed-use e --max-credits=N com autorização e saldo suficientes para a estimativa.');
mkdirSync(cacheDir,{recursive:true});
mkdirSync(folder,{recursive:true});
for(const entry of entries) {
  if(entry.local)continue;
  if(!existsSync(entry.cache)){
    const response=await fetch(`${url}/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`,{
      method:'POST',headers:{...headers,'content-type':'application/json',accept:'audio/mpeg'},
      body:JSON.stringify(entry.body),signal:AbortSignal.timeout(90000),
    });
    if(!response.ok)throw Error(`ElevenLabs retornou HTTP ${response.status} na cena ${entry.scene}.`);
    const bytes=Buffer.from(await response.arrayBuffer());
    if(!response.headers.get('content-type')?.startsWith('audio/')||bytes.length<1024)throw Error('O serviço não retornou áudio utilizável.');
    writeFileSync(entry.cache+'.partial',bytes);
    renameSync(entry.cache+'.partial',entry.cache);
  }
  writeFileSync(resolve(folder,entry.stem+'.mp3'),readFileSync(entry.cache),{flag:'wx'});
}
